SuperStrict

Import BRL.StandardIO
Import BRL.FileSystem
Import BRL.Pixmap
Import BRL.PNGLoader
Import BRL.JPGLoader


' ============================================================
' DEPACKER V13
'
' CLI:
'
' depacker_v13.exe <dataset.dat> <output_folder>
'
' Example:
'
' depacker_v13.exe "D:\dataset.dat" "D:\decoded"
'
' Parameter 1 = dataset.dat
' Parameter 2 = output folder
'
' The output folder is created if it does not exist.
'
' Original filenames are preserved.
'
' Example:
'
' fodex.png
'
' becomes:
'
' output\fodex.png
'
' NOT:
'
' fodex_decoded.png
'
' ============================================================


Const HEADER_VERSION:Int = 12
Const BLOCK_SIZE:Int = 8
Const BLOCK_PIXELS:Int = 64

Const CODEBOOK_Y:Int = 4096
Const CODEBOOK_U:Int = 1024
Const CODEBOOK_V:Int = 1024
Const CODEBOOK_A:Int = 256

Const BLOCK_DATA:Int = 144


' ============================================================
' UTIL
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then value = 0
	If value > 255 Then value = 255

	Return value

End Function


Function ByteValue:Int(value:Byte)

	Return Int(value) & $FF

End Function


Function MakePixel:Int(r:Int,g:Int,b:Int,a:Int)

	r = ClampByte(r)
	g = ClampByte(g)
	b = ClampByte(b)
	a = ClampByte(a)

	Return (a Shl 24) | (r Shl 16) | (g Shl 8) | b

End Function


Function JoinPath:String(folder:String,name:String)

	Local result:String

	result = folder

	If result.EndsWith("/") = False And result.EndsWith("\") = False Then
		result :+ "/"
	EndIf

	result :+ name

	Return result

End Function


' ============================================================
' CREATE DIRECTORY TREE
' ============================================================

Function EnsureDirectoryTree:Int(path:String)

	If path = "" Then Return True

	If FileType(path) = FILETYPE_DIR Then
		Return True
	EndIf

	Local parent:String

	parent = ExtractDir(path)

	If parent <> "" And parent <> path Then

		If FileType(parent) <> FILETYPE_DIR Then

			If EnsureDirectoryTree(parent) = False Then
				Return False
			EndIf

		EndIf

	EndIf

	CreateDir(path)

	If FileType(path) = FILETYPE_DIR Then
		Return True
	EndIf

	Return False

End Function

' ============================================================
' DIRECTORY FROM FILE PATH
' ============================================================

Function EnsureParentDirectory:Int(filename:String)

	Local directory:String

	directory = ExtractDir(filename)

	If directory = "" Then
		Return True
	EndIf

	Return EnsureDirectoryTree(directory)

End Function


' ============================================================
' READ STREAM
' ============================================================

Function ReadU8:Int(stream:TStream)

	Return stream.ReadByte() & $FF

End Function


Function ReadU16LE:Int(stream:TStream)

	Local b0:Int
	Local b1:Int

	b0 = ReadU8(stream)
	b1 = ReadU8(stream)

	Return b0 | (b1 Shl 8)

End Function


Function ReadU32LE:Long(stream:TStream)

	Local b0:Long
	Local b1:Long
	Local b2:Long
	Local b3:Long

	b0 = ReadU8(stream)
	b1 = ReadU8(stream)
	b2 = ReadU8(stream)
	b3 = ReadU8(stream)

	Return b0 | (b1 Shl 8) | (b2 Shl 16) | (b3 Shl 24)

End Function


Function ReadU64LE:Long(stream:TStream)

	Local value:Long

	value = 0

	For Local n:Int = 0 Until 8

		Local b:Long

		b = ReadU8(stream)

		value :| b Shl (n * 8)

	Next

	Return value

End Function


Function ReadASCII:String(stream:TStream,length:Int)

	Local result:String

	result = ""

	For Local n:Int = 0 Until length

		result :+ Chr(ReadU8(stream))

	Next

	Return result

End Function


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int
	Field data:Byte[]
	Field filled:Int

End Type


Function CreateCodeBook:TCodeBook(size:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = size
	book.data = New Byte[size * BLOCK_PIXELS]
	book.filled = size

	Return book

End Function


Function GetBookValue:Int(book:TCodeBook,code:Int,pos:Int)

	If code < 0 Then Return 0
	If code >= book.size Then Return 0
	If pos < 0 Then Return 0
	If pos >= BLOCK_PIXELS Then Return 0

	Return ByteValue(book.data[code * BLOCK_PIXELS + pos])

End Function


' ============================================================
' SAFE TENSOR
' ============================================================

Function ReadSafeTensor:Int(stream:TStream,expectedName:String,book:TCodeBook)

	Local magic:String

	magic = ReadASCII(stream,4)

	If magic <> "SAFE" Then

		Print "ERRO: SAFE tensor invalido."
		Return False

	EndIf


	Local tensorBytes:Long

	tensorBytes = ReadU64LE(stream)


	Local nameLength:Long

	nameLength = ReadU32LE(stream)

	If nameLength < 0 Or nameLength > 1048576 Then

		Print "ERRO: nome do tensor invalido."
		Return False

	EndIf


	Local name:String

	name = ReadASCII(stream,Int(nameLength))

	If name <> expectedName Then

		Print "ERRO: tensor esperado = " + expectedName
		Print "Tensor encontrado = " + name

		Return False

	EndIf


	Local tensorSize:Long

	tensorSize = ReadU32LE(stream)

	If tensorSize <> book.size Then

		Print "ERRO: tamanho do tensor incorreto."
		Print "Esperado = " + book.size
		Print "Encontrado = " + tensorSize

		Return False

	EndIf


	Local expectedBytes:Long

	expectedBytes = Long(book.size) * BLOCK_PIXELS

	If tensorBytes <> expectedBytes Then

		Print "ERRO: numero de bytes do tensor incorreto."
		Print "Esperado = " + expectedBytes
		Print "Encontrado = " + tensorBytes

		Return False

	EndIf


	For Local n:Long = 0 Until tensorBytes

		book.data[Int(n)] = Byte(ReadU8(stream))

	Next


	book.filled = book.size

	Return True

End Function


' ============================================================
' YUV -> RGB
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)
	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)
	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' DECODE ONE IMAGE
' ============================================================

Function DecodeImage:Int(stream:TStream,outputFolder:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,imageNumber:Long,totalImages:Long)

	Local relativeLength:Long

	relativeLength = ReadU32LE(stream)

	If relativeLength < 0 Or relativeLength > 10485760 Then

		Print "ERRO: comprimento do nome da imagem invalido."
		Return False

	EndIf


	Local relative:String

	relative = ReadASCII(stream,Int(relativeLength))

	relative = relative.Replace("\","/")


	Local width:Long
	Local height:Long

	width = ReadU32LE(stream)
	height = ReadU32LE(stream)


	If width <= 0 Or height <= 0 Then

		Print "ERRO: dimensao invalida."
		Print relative

		Return False

	EndIf


	If width > 100000 Or height > 100000 Then

		Print "ERRO: dimensao demasiado grande."
		Print relative

		Return False

	EndIf


	Local blocksX:Long
	Local blocksY:Long
	Local totalBlocks:Long

	blocksX = ReadU32LE(stream)
	blocksY = ReadU32LE(stream)
	totalBlocks = ReadU64LE(stream)


	Local calculatedBlocks:Long

	calculatedBlocks = blocksX * blocksY

	If totalBlocks <> calculatedBlocks Then

		Print "ERRO: total de blocos invalido."
		Return False

	EndIf


	Print ""
	Print "------------------------------------------"
	Print "IMAGEM " + imageNumber + " / " + totalImages
	Print "FICHEIRO = " + relative
	Print "TAMANHO = " + width + " x " + height
	Print "BLOCOS = " + blocksX + " x " + blocksY
	Print "TOTAL = " + totalBlocks


	' ========================================================
	' IMPORTANT:
	'
	' Preserve the original filename.
	'
	' If relative = fodex.png
	'
	' output = outputFolder/fodex.png
	'
	' If relative = animals/cat.png
	'
	' output = outputFolder/animals/cat.png
	' ========================================================

	Local outputName:String

	outputName = JoinPath(outputFolder,relative)


	If EnsureParentDirectory(outputName) = False Then

		Print "ERRO: nao conseguiu criar a pasta:"
		Print ExtractDir(outputName)

		Return False

	EndIf


	Local output:TPixmap

	output = CreatePixmap(Int(width),Int(height),PF_RGBA8888)

	If output = Null Then

		Print "ERRO: nao conseguiu criar pixmap."
		Return False

	EndIf


	' ========================================================
	' BLOCK BUFFERS
	' ========================================================

	Local yCodes:Int
	Local uCodes:Int
	Local vCodes:Int
	Local unused:Int

	yCodes = 0
	uCodes = 0
	vCodes = 0
	unused = 0


	For Local by:Long = 0 Until blocksY

		For Local bx:Long = 0 Until blocksX

			' --------------------------------------------------
			' CODES
			' --------------------------------------------------

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int
			Local reserved:Int

			codeY = ReadU16LE(stream)
			codeU = ReadU16LE(stream)
			codeV = ReadU16LE(stream)
			reserved = ReadU16LE(stream)


			If codeY >= bookY.size Then

				Print "ERRO: codeY invalido."
				Return False

			EndIf


			If codeU >= bookU.size Then

				Print "ERRO: codeU invalido."
				Return False

			EndIf


			If codeV >= bookV.size Then

				Print "ERRO: codeV invalido."
				Return False

			EndIf


			' --------------------------------------------------
			' Y RESIDUAL
			' --------------------------------------------------

			Local yResidual:Int[]

			yResidual = New Int[64]

			For Local p:Int = 0 Until 64

				yResidual[p] = ReadU8(stream) - 128

			Next


			' --------------------------------------------------
			' U RESIDUAL
			' --------------------------------------------------

			Local residualU:Int[]

			residualU = New Int[4]

			For Local group:Int = 0 Until 4

				residualU[group] = ReadU8(stream) - 128

			Next


			' --------------------------------------------------
			' V RESIDUAL
			' --------------------------------------------------

			Local residualV:Int[]

			residualV = New Int[4]

			For Local group:Int = 0 Until 4

				residualV[group] = ReadU8(stream) - 128

			Next


			' --------------------------------------------------
			' ALPHA
			' --------------------------------------------------

			Local alpha:Int[]

			alpha = New Int[64]

			For Local p:Int = 0 Until 64

				alpha[p] = ReadU8(stream)

			Next


			' --------------------------------------------------
			' RECONSTRUCT PIXELS
			' --------------------------------------------------

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local p:Int

					p = yy * 8 + xx


					' ------------------------------------------
					' Y
					' ------------------------------------------

					Local yValue:Int

					yValue = GetBookValue(bookY,codeY,p)

					yValue :+ yResidual[p]

					yValue :* 2

					yValue = ClampByte(yValue)


					' ------------------------------------------
					' U / V
					' ------------------------------------------

					Local group:Int

					group = (yy / 4) * 2 + (xx / 4)


					Local uValue:Int
					Local vValue:Int

					uValue = GetBookValue(bookU,codeU,p)
					uValue :+ residualU[group]
					uValue :* 2
					uValue = ClampByte(uValue)


					vValue = GetBookValue(bookV,codeV,p)
					vValue :+ residualV[group]
					vValue :* 2
					vValue = ClampByte(vValue)


					' ------------------------------------------
					' POSITION
					' ------------------------------------------

					Local px:Int
					Local py:Int

					px = Int(bx) * 8 + xx
					py = Int(by) * 8 + yy


					If px < Int(width) And py < Int(height) Then

						Local r:Int
						Local g:Int
						Local b:Int

						r = YUVToR(yValue,uValue,vValue)
						g = YUVToG(yValue,uValue,vValue)
						b = YUVToB(yValue,uValue,vValue)


						WritePixel(output,px,py,MakePixel(r,g,b,alpha[p]))

					EndIf

				Next

			Next

		Next

	Next


	' ========================================================
	' SAVE
	'
	' IMPORTANT:
	' Same filename as the original.
	' ========================================================

Local success:Int

Local lowerName:String

lowerName = outputName.ToLower()


Print ""
Print "A GUARDAR:"
Print outputName


' ========================================================
' GARANTIR QUE A PASTA DA IMAGEM EXISTE
' ========================================================

Local imageFolder:String

imageFolder = ExtractDir(outputName)

Print "PASTA:"
Print imageFolder

If imageFolder <> "" Then

	If EnsureDirectoryTree(imageFolder) = False Then

		Print "ERRO: nao conseguiu criar a pasta:"
		Print imageFolder

		Return False

	EndIf

EndIf


' ========================================================
' PNG
' ========================================================

If lowerName.EndsWith(".png") Then

	Print "FORMATO = PNG"

	success = SavePixmapPNG(output,outputName,5)


' ========================================================
' JPEG
' ========================================================

ElseIf lowerName.EndsWith(".jpg") Then

	Print "FORMATO = JPEG"

	success = SavePixmapJPeg(output,outputName)


ElseIf lowerName.EndsWith(".jpeg") Then

	Print "FORMATO = JPEG"

	success = SavePixmapJPeg(output,outputName)


Else

	Print "ERRO: formato de imagem nao suportado:"
	Print outputName

	Return False

EndIf


' ========================================================
' RESULTADO
' ========================================================

If success = False Then

	Print ""
	Print "ERRO AO GUARDAR:"
	Print outputName
	Print ""

	Return False

EndIf


Print "GUARDADA COM SUCESSO."

Return True

End function


' ============================================================
' MAIN DEPACK
' ============================================================

Function DepackDataset:Int(datasetName:String,outputFolder:String)

	Print ""
	Print "=========================================="
	Print "DEPACKER V13"
	Print "=========================================="

	Print "DATASET = " + datasetName
	Print "OUTPUT  = " + outputFolder
	Print ""


	' ========================================================
	' CHECK DATASET
	' ========================================================

	If FileType(datasetName) <> FILETYPE_FILE Then

		Print "ERRO: dataset nao encontrado:"
		Print datasetName

		Return False

	EndIf


	' ========================================================
	' CREATE OUTPUT FOLDER
	' ========================================================

	If EnsureDirectoryTree(outputFolder) = False Then

		Print "ERRO: nao conseguiu criar a pasta de output:"
		Print outputFolder

		Return False

	EndIf


	Print "Pasta de output OK."


	' ========================================================
	' OPEN DATASET
	' ========================================================

	Local stream:TStream

	stream = ReadStream(datasetName)

	If stream = Null Then

		Print "ERRO: nao conseguiu abrir dataset."
		Return False

	EndIf


	' ========================================================
	' DATASET HEADER
	' ========================================================

	Local magic:String

	magic = ReadASCII(stream,4)

	If magic <> "DSET" Then

		Print "ERRO: ficheiro nao e um dataset DSET."

		CloseStream(stream)

		Return False

	EndIf


	Local version:Long
	Local blockSize:Long
	Local blockData:Long

	version = ReadU32LE(stream)
	blockSize = ReadU32LE(stream)
	blockData = ReadU32LE(stream)


	Print "VERSION = " + version
	Print "BLOCK SIZE = " + blockSize
	Print "BLOCK DATA = " + blockData


	If version <> HEADER_VERSION Then

		Print "AVISO: versao diferente."
		Print "Esperado = " + HEADER_VERSION
		Print "Encontrado = " + version

	EndIf


	If blockSize <> BLOCK_SIZE Then

		Print "ERRO: BLOCK_SIZE incompatível."

		CloseStream(stream)

		Return False

	EndIf


	If blockData <> BLOCK_DATA Then

		Print "ERRO: BLOCK_DATA incompatível."

		CloseStream(stream)

		Return False

	EndIf


	' ========================================================
	' CODEBOOK SIZES
	' ========================================================

	Local sizeY:Long
	Local sizeU:Long
	Local sizeV:Long
	Local sizeA:Long

	sizeY = ReadU32LE(stream)
	sizeU = ReadU32LE(stream)
	sizeV = ReadU32LE(stream)
	sizeA = ReadU32LE(stream)


	If sizeY <> CODEBOOK_Y Then

		Print "ERRO: CODEBOOK Y incompatível."
		CloseStream(stream)
		Return False

	EndIf


	If sizeU <> CODEBOOK_U Then

		Print "ERRO: CODEBOOK U incompatível."
		CloseStream(stream)
		Return False

	EndIf


	If sizeV <> CODEBOOK_V Then

		Print "ERRO: CODEBOOK V incompatível."
		CloseStream(stream)
		Return False

	EndIf


	If sizeA <> CODEBOOK_A Then

		Print "ERRO: CODEBOOK A incompatível."
		CloseStream(stream)
		Return False

	EndIf


	' ========================================================
	' QUALITY
	' ========================================================

	Local quality:Long

	quality = ReadU32LE(stream)

	Print "QUALITY = " + quality


	' ========================================================
	' IMAGE COUNT
	' ========================================================

	Local imageCount:Long

	imageCount = ReadU64LE(stream)

	Print "IMAGENS = " + imageCount


	If imageCount <= 0 Then

		Print "ERRO: dataset nao contem imagens."

		CloseStream(stream)

		Return False

	EndIf


	' ========================================================
	' CODEBOOKS
	' ========================================================

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	bookY = CreateCodeBook(CODEBOOK_Y)
	bookU = CreateCodeBook(CODEBOOK_U)
	bookV = CreateCodeBook(CODEBOOK_V)
	bookA = CreateCodeBook(CODEBOOK_A)


	' ========================================================
	' SAFE
	' ========================================================

	Local safeMagic:String

	safeMagic = ReadASCII(stream,4)

	If safeMagic <> "SAFE" Then

		Print "ERRO: SAFE section nao encontrada."

		CloseStream(stream)

		Return False

	EndIf


	Print ""
	Print "A LER CODEBOOK Y..."

	If ReadSafeTensor(stream,"datasetY",bookY) = False Then

		CloseStream(stream)

		Return False

	EndIf

	Print "Y OK"


	Print "A LER CODEBOOK U..."

	If ReadSafeTensor(stream,"datasetU",bookU) = False Then

		CloseStream(stream)

		Return False

	EndIf

	Print "U OK"


	Print "A LER CODEBOOK V..."

	If ReadSafeTensor(stream,"datasetV",bookV) = False Then

		CloseStream(stream)

		Return False

	EndIf

	Print "V OK"


	Print "A LER CODEBOOK A..."

	If ReadSafeTensor(stream,"datasetA",bookA) = False Then

		CloseStream(stream)

		Return False

	EndIf

	Print "A OK"


	' ========================================================
	' IMAGES SECTION
	' ========================================================

	Local imageMagic:String

	imageMagic = ReadASCII(stream,4)

	If imageMagic <> "IMGS" Then

		Print "ERRO: secção IMGS nao encontrada."

		CloseStream(stream)

		Return False

	EndIf


	' ========================================================
	' DECODE IMAGES
	' ========================================================

	Local decodedCount:Long

	decodedCount = 0


	For Local imageNumber:Long = 1 To imageCount

		If AppTerminate() Then

			Print ""
			Print "PROCESSO INTERROMPIDO."

			CloseStream(stream)

			Return False

		EndIf


		If DecodeImage(stream,outputFolder,bookY,bookU,bookV,bookA,imageNumber,imageCount) = False Then

			Print ""
			Print "ERRO AO DESCODIFICAR IMAGEM " + imageNumber

			CloseStream(stream)

			Return False

		EndIf


		decodedCount :+ 1

	Next


	' ========================================================
	' END
	' ========================================================

	Local endMagic:String

	endMagic = ReadASCII(stream,4)

	If endMagic <> "END!" Then

		Print ""
		Print "ERRO: END! nao encontrado no final do dataset."

		CloseStream(stream)

		Return False

	EndIf


	CloseStream(stream)


	' ========================================================
	' FINISHED
	' ========================================================

	Print ""
	Print "=========================================="
	Print "DEPACKER V13 TERMINADO"
	Print "=========================================="

	Print "DATASET = " + datasetName
	Print "OUTPUT = " + outputFolder
	Print "IMAGENS = " + decodedCount
	Print ""
	Print "Todas as imagens foram descodificadas."
	Print "Os nomes originais foram preservados."
	Print "=========================================="


	Return True

End Function


' ============================================================
' MAIN
'
' CLI:
'
' depacker_v13.exe dataset.dat output_folder
'
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DEPACKER V13"
	Print "BLITZMAX NG"
	Print "=========================================="
	Print ""


	Local args:String[]

	args = AppArgs


	If args = Null Then

		Print "ERRO: argumentos nao encontrados."
		Print ""
		Print "Uso:"
		Print "depacker_v13.exe <dataset.dat> <output_folder>"
		Print ""

		Return

	EndIf


	' AppArgs(0) = executable
	' AppArgs(1) = dataset.dat
	' AppArgs(2) = output folder


	If args.Length < 3 Then

		Print "ERRO: argumentos insuficientes."
		Print ""
		Print "Uso:"
		Print "depacker_v13.exe <dataset.dat> <output_folder>"
		Print ""
		Print "Exemplo:"
		Print "depacker_v13.exe D:\dataset.dat D:\decoded"
		Print ""

		Return

	EndIf


	Local datasetName:String
	Local outputFolder:String

	datasetName = args[1]
	outputFolder = args[2]


	If datasetName = "" Then

		Print "ERRO: dataset vazio."
		Return

	EndIf


	If outputFolder = "" Then

		Print "ERRO: output folder vazio."
		Return

	EndIf


	DepackDataset(datasetName,outputFolder)


	Print ""
	Print "Processo terminado."

End Function


Main()