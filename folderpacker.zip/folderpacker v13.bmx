SuperStrict

Import BRL.StandardIO
Import BRL.FileSystem
Import BRL.LinkedList
Import BRL.Pixmap
Import BRL.PNGLoader
Import BRL.JPGLoader
Import BRL.Max2D
Import BRL.Graphics


Graphics 1920,1080


Const HEADER_VERSION:Int = 12
Const BLOCK_SIZE:Int = 8
Const BLOCK_PIXELS:Int = 64

Const CODEBOOK_Y:Int = 4096
Const CODEBOOK_U:Int = 1024
Const CODEBOOK_V:Int = 1024
Const CODEBOOK_A:Int = 256

Const BLOCK_DATA:Int = 144

Const TRAIN_SAMPLE:Int = 8
Const TRAIN_MAX_BLOCKS:Long = 32768


' ============================================================
' UTIL
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then value = 0
	If value > 255 Then value = 255

	Return value

End Function


Function ClampResidual:Int(value:Int)

	If value < -127 Then value = -127
	If value > 127 Then value = 127

	Return value

End Function


Function ByteValue:Int(value:Byte)

	Return Int(value) & $FF

End Function


Function MakePixel:Int(r:Int,g:Int,b:Int,a:Int)

	r = ClampByte(r)
	g = ClampByte(g)
	b = ClampByte(b)
	a = ClampByte(a)

	Return (a Shl 24) | (r Shl 16) | (g Shl 8) | b

End Function


Function PixelR:Int(pixel:Int)

	Return (pixel Shr 16) & $FF

End Function


Function PixelG:Int(pixel:Int)

	Return (pixel Shr 8) & $FF

End Function


Function PixelB:Int(pixel:Int)

	Return pixel & $FF

End Function


Function PixelA:Int(pixel:Int)

	Return (pixel Shr 24) & $FF

End Function


Function JoinPath:String(folder:String,name:String)

	Local result:String

	result = folder

	If result.EndsWith("/") = False And result.EndsWith("\") = False Then
		result :+ "/"
	EndIf

	result :+ name

	Return result

End Function


Function IsImageFile:Int(filename:String)

	Local nameLower:String

	nameLower = filename.ToLower()

	If nameLower.EndsWith(".png") Then Return True
	If nameLower.EndsWith(".jpg") Then Return True
	If nameLower.EndsWith(".jpeg") Then Return True

	Return False

End Function


Function MakeRelativePath:String(fullName:String,root:String)

	Local relative:String

	relative = fullName

	If relative.StartsWith(root) Then
		relative = relative[root.Length..]
	EndIf

	While relative.StartsWith("/") Or relative.StartsWith("\")
		relative = relative[1..]
	Wend

	relative = relative.Replace("\","/")

	Return relative

End Function


' ============================================================
' COUNT IMAGES
'
' Does NOT store filenames in memory.
' ============================================================

Function CountImageFiles:Long(folder:String)

	Local entries:String[]

	entries = LoadDir(folder,True)

	If entries = Null Then Return 0

	Local total:Long

	total = 0

	For Local entry:String = EachIn entries

		If entry = "" Then Continue
		If entry = "." Then Continue
		If entry = ".." Then Continue

		Local fullName:String

		fullName = JoinPath(folder,entry)

		Local kind:Int

		kind = FileType(fullName)

		If kind = FILETYPE_DIR Then

			total :+ CountImageFiles(fullName)

		ElseIf kind = FILETYPE_FILE Then

			If IsImageFile(fullName) Then
				total :+ 1
			EndIf

		EndIf

	Next

	Return total

End Function


' ============================================================
' RGB -> YUV
' ============================================================

Function RGBToY:Int(r:Int,g:Int,b:Int)

	Local value:Float

	value = 0.299 * Float(r)
	value :+ 0.587 * Float(g)
	value :+ 0.114 * Float(b)

	Return ClampByte(Int(value))

End Function


Function RGBToU:Int(r:Int,g:Int,b:Int)

	Local value:Float

	value = -0.168736 * Float(r)
	value :- 0.331264 * Float(g)
	value :+ 0.5 * Float(b)
	value :+ 128.0

	Return ClampByte(Int(value))

End Function


Function RGBToV:Int(r:Int,g:Int,b:Int)

	Local value:Float

	value = 0.5 * Float(r)
	value :- 0.418688 * Float(g)
	value :- 0.081312 * Float(b)
	value :+ 128.0

	Return ClampByte(Int(value))

End Function


' ============================================================
' YUV -> RGB
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)
	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)
	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int
	Field data:Byte[]
	Field filled:Int

End Type


Function CreateCodeBook:TCodeBook(size:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = size
	book.data = New Byte[size * BLOCK_PIXELS]
	book.filled = 0

	Return book

End Function


Function SetBookValue(book:TCodeBook,code:Int,pos:Int,value:Int)

	If code < 0 Then Return
	If code >= book.size Then Return
	If pos < 0 Then Return
	If pos >= BLOCK_PIXELS Then Return

	book.data[code * BLOCK_PIXELS + pos] = Byte(ClampByte(value))

End Function


Function GetBookValue:Int(book:TCodeBook,code:Int,pos:Int)

	If code < 0 Then Return 0
	If code >= book.size Then Return 0
	If pos < 0 Then Return 0
	If pos >= BLOCK_PIXELS Then Return 0

	Return ByteValue(book.data[code * BLOCK_PIXELS + pos])

End Function


Function AddBlockToBook(book:TCodeBook,values:Int[])

	If book.filled >= book.size Then Return

	Local code:Int

	code = book.filled

	For Local p:Int = 0 Until BLOCK_PIXELS

		SetBookValue(book,code,p,values[p])

	Next

	book.filled :+ 1

End Function


Function FillRemainingBook(book:TCodeBook)

	If book.filled = 0 Then

		For Local p:Int = 0 Until BLOCK_PIXELS
			SetBookValue(book,0,p,0)
		Next

		book.filled = 1

	EndIf

	For Local code:Int = book.filled Until book.size

		Local source:Int

		source = code Mod book.filled

		For Local p:Int = 0 Until BLOCK_PIXELS

			SetBookValue(book,code,p,GetBookValue(book,source,p))

		Next

	Next

	book.filled = book.size

End Function


' ============================================================
' IMAGE
' ============================================================

Function LoadInputPixmap:TPixmap(filename:String)

	Local pixmap:TPixmap

	pixmap = LoadPixmap(filename)

	If pixmap = Null Then Return Null

	If pixmap.format <> PF_RGBA8888 Then

		Local converted:TPixmap

		converted = ConvertPixmap(pixmap,PF_RGBA8888)

		If converted <> Null Then
			pixmap = converted
		EndIf

	EndIf

	Return pixmap

End Function


' ============================================================
' BLOCK Y
' ============================================================

Function GetBlockY(pixmap:TPixmap,bx:Int,by:Int,values:Int[])

	For Local yy:Int = 0 Until 8

		For Local xx:Int = 0 Until 8

			Local px:Int
			Local py:Int

			px = bx * 8 + xx
			py = by * 8 + yy

			Local pixel:Int

			pixel = 0

			If px < pixmap.width And py < pixmap.height Then
				pixel = ReadPixel(pixmap,px,py)
			EndIf

			values[yy * 8 + xx] = RGBToY(PixelR(pixel),PixelG(pixel),PixelB(pixel)) / 2

		Next

	Next

End Function


' ============================================================
' BLOCK U
' ============================================================

Function GetBlockU(pixmap:TPixmap,bx:Int,by:Int,values:Int[])

	For Local yy:Int = 0 Until 8

		For Local xx:Int = 0 Until 8

			Local px:Int
			Local py:Int

			px = bx * 8 + xx
			py = by * 8 + yy

			Local pixel:Int

			pixel = 0

			If px < pixmap.width And py < pixmap.height Then
				pixel = ReadPixel(pixmap,px,py)
			EndIf

			values[yy * 8 + xx] = RGBToU(PixelR(pixel),PixelG(pixel),PixelB(pixel)) / 2

		Next

	Next

End Function


' ============================================================
' BLOCK V
' ============================================================

Function GetBlockV(pixmap:TPixmap,bx:Int,by:Int,values:Int[])

	For Local yy:Int = 0 Until 8

		For Local xx:Int = 0 Until 8

			Local px:Int
			Local py:Int

			px = bx * 8 + xx
			py = by * 8 + yy

			Local pixel:Int

			pixel = 0

			If px < pixmap.width And py < pixmap.height Then
				pixel = ReadPixel(pixmap,px,py)
			EndIf

			values[yy * 8 + xx] = RGBToV(PixelR(pixel),PixelG(pixel),PixelB(pixel)) / 2

		Next

	Next

End Function


' ============================================================
' BLOCK ALPHA
' ============================================================

Function GetBlockA(pixmap:TPixmap,bx:Int,by:Int,values:Int[])

	For Local yy:Int = 0 Until 8

		For Local xx:Int = 0 Until 8

			Local px:Int
			Local py:Int

			px = bx * 8 + xx
			py = by * 8 + yy

			Local alpha:Int

			alpha = 0

			If px < pixmap.width And py < pixmap.height Then
				alpha = PixelA(ReadPixel(pixmap,px,py))
			EndIf

			values[yy * 8 + xx] = alpha

		Next

	Next

End Function


' ============================================================
' DISTANCE
' ============================================================

Function BlockDistance:Long(book:TCodeBook,code:Int,values:Int[])

	Local distance:Long

	distance = 0

	For Local p:Int = 0 Until 64

		Local d:Int

		d = GetBookValue(book,code,p) - values[p]

		distance :+ Long(d) * Long(d)

	Next

	Return distance

End Function


Function FindBestCode:Int(book:TCodeBook,values:Int[])

	Local bestCode:Int
	Local bestDistance:Long

	bestCode = 0
	bestDistance = BlockDistance(book,0,values)

	For Local code:Int = 1 Until book.size

		Local distance:Long

		distance = BlockDistance(book,code,values)

		If distance < bestDistance Then

			bestDistance = distance
			bestCode = code

		EndIf

	Next

	Return bestCode

End Function


' ============================================================
' TRAIN
' ============================================================

Function TrainCodeBooksFolder(folder:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,examined:Long Var,samples:Long Var)

	If examined >= TRAIN_MAX_BLOCKS Then Return

	Local entries:String[]

	entries = LoadDir(folder,True)

	If entries = Null Then Return

	Local yBlock:Int[]
	Local uBlock:Int[]
	Local vBlock:Int[]

	yBlock = New Int[64]
	uBlock = New Int[64]
	vBlock = New Int[64]

	For Local entry:String = EachIn entries

		If examined >= TRAIN_MAX_BLOCKS Then Return

		If entry = "" Then Continue
		If entry = "." Then Continue
		If entry = ".." Then Continue

		Local fullName:String

		fullName = JoinPath(folder,entry)

		Local kind:Int

		kind = FileType(fullName)

		If kind = FILETYPE_DIR Then

			TrainCodeBooksFolder(fullName,bookY,bookU,bookV,examined,samples)

			Continue

		EndIf

		If kind <> FILETYPE_FILE Then Continue
		If IsImageFile(fullName) = False Then Continue

		Print "Treino: " + fullName

		Local pixmap:TPixmap

		pixmap = LoadInputPixmap(fullName)

		If pixmap = Null Then

			Print "  ERRO AO CARREGAR NO TREINO"
			Continue

		EndIf

		Local blocksX:Long
		Local blocksY:Long

		blocksX = (Long(pixmap.width) + 7) / 8
		blocksY = (Long(pixmap.height) + 7) / 8

		For Local by:Long = 0 Until blocksY

			If examined >= TRAIN_MAX_BLOCKS Then Return

			For Local bx:Long = 0 Until blocksX

				If examined >= TRAIN_MAX_BLOCKS Then Return

				examined :+ 1

				If examined Mod TRAIN_SAMPLE = 0 Then

					GetBlockY(pixmap,Int(bx),Int(by),yBlock)
					GetBlockU(pixmap,Int(bx),Int(by),uBlock)
					GetBlockV(pixmap,Int(bx),Int(by),vBlock)

					If bookY.filled < bookY.size Then
						AddBlockToBook(bookY,yBlock)
					EndIf

					If bookU.filled < bookU.size Then
						AddBlockToBook(bookU,uBlock)
					EndIf

					If bookV.filled < bookV.size Then
						AddBlockToBook(bookV,vBlock)
					EndIf

					samples :+ 1

					If samples Mod 128 = 0 Then

						Print "  blocos examinados = " + examined
						Print "  amostras = " + samples
						Print "  Y = " + bookY.filled + " / " + bookY.size
						Print "  U = " + bookU.filled + " / " + bookU.size
						Print "  V = " + bookV.filled + " / " + bookV.size

					EndIf

				EndIf

			Next

		Next

	Next

End Function


' ============================================================
' STREAM
' ============================================================

Function WriteU8(stream:TStream,value:Int)

	stream.WriteByte(value & $FF)

End Function


Function WriteU16LE(stream:TStream,value:Int)

	WriteU8(stream,value)
	WriteU8(stream,value Shr 8)

End Function


Function WriteU32LE(stream:TStream,value:Long)

	WriteU8(stream,Int(value & $FF))
	WriteU8(stream,Int((value Shr 8) & $FF))
	WriteU8(stream,Int((value Shr 16) & $FF))
	WriteU8(stream,Int((value Shr 24) & $FF))

End Function


Function WriteU64LE(stream:TStream,value:Long)

	For Local n:Int = 0 Until 8

		WriteU8(stream,Int((value Shr (n * 8)) & $FF))

	Next

End Function


Function WriteASCII(stream:TStream,text:String)

	For Local n:Int = 0 Until text.Length

		WriteU8(stream,Int(text[n]))

	Next

End Function


' ============================================================
' SAFE TENSOR
' ============================================================

Function WriteSafeTensor(stream:TStream,name:String,book:TCodeBook)

	Local tensorBytes:Long

	tensorBytes = Long(book.size) * 64

	WriteASCII(stream,"SAFE")
	WriteU64LE(stream,tensorBytes)

	WriteU32LE(stream,Long(name.Length))
	WriteASCII(stream,name)

	WriteU32LE(stream,Long(book.size))

	For Local n:Long = 0 Until tensorBytes

		WriteU8(stream,ByteValue(book.data[Int(n)]))

	Next

End Function


' ============================================================
' IMAGE HEADER
' ============================================================

Function WriteImageHeader(stream:TStream,relative:String,width:Int,height:Int,blocksX:Long,blocksY:Long)

	WriteU32LE(stream,Long(relative.Length))
	WriteASCII(stream,relative)

	WriteU32LE(stream,Long(width))
	WriteU32LE(stream,Long(height))

	WriteU32LE(stream,blocksX)
	WriteU32LE(stream,blocksY)

	WriteU64LE(stream,blocksX * blocksY)

End Function


' ============================================================
' ENCODE BLOCK
' ============================================================

Function EncodeBlock(stream:TStream,pixmap:TPixmap,bx:Int,by:Int,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook)

	Local yBlock:Int[]
	Local uBlock:Int[]
	Local vBlock:Int[]
	Local aBlock:Int[]

	yBlock = New Int[64]
	uBlock = New Int[64]
	vBlock = New Int[64]
	aBlock = New Int[64]

	GetBlockY(pixmap,bx,by,yBlock)
	GetBlockU(pixmap,bx,by,uBlock)
	GetBlockV(pixmap,bx,by,vBlock)
	GetBlockA(pixmap,bx,by,aBlock)

	Local codeY:Int
	Local codeU:Int
	Local codeV:Int

	codeY = FindBestCode(bookY,yBlock)
	codeU = FindBestCode(bookU,uBlock)
	codeV = FindBestCode(bookV,vBlock)

	WriteU16LE(stream,codeY)
	WriteU16LE(stream,codeU)
	WriteU16LE(stream,codeV)
	WriteU16LE(stream,0)

	For Local p:Int = 0 Until 64

		Local residual:Int

		residual = yBlock[p] - GetBookValue(bookY,codeY,p)
		residual = ClampResidual(residual)

		WriteU8(stream,residual + 128)

	Next

	For Local group:Int = 0 Until 4

		Local sum:Long

		sum = 0

		Local gx:Int
		Local gy:Int

		gx = (group Mod 2) * 4
		gy = (group / 2) * 4

		For Local yy:Int = gy Until gy + 4

			For Local xx:Int = gx Until gx + 4

				Local p:Int

				p = yy * 8 + xx

				sum :+ Long(uBlock[p] - GetBookValue(bookU,codeU,p))

			Next

		Next

		Local residual:Int

		residual = Int(sum / 16)
		residual = ClampResidual(residual)

		WriteU8(stream,residual + 128)

	Next

	For Local group:Int = 0 Until 4

		Local sum:Long

		sum = 0

		Local gx:Int
		Local gy:Int

		gx = (group Mod 2) * 4
		gy = (group / 2) * 4

		For Local yy:Int = gy Until gy + 4

			For Local xx:Int = gx Until gx + 4

				Local p:Int

				p = yy * 8 + xx

				sum :+ Long(vBlock[p] - GetBookValue(bookV,codeV,p))

			Next

		Next

		Local residual:Int

		residual = Int(sum / 16)
		residual = ClampResidual(residual)

		WriteU8(stream,residual + 128)

	Next

	For Local p:Int = 0 Until 64

		WriteU8(stream,aBlock[p])

	Next

End Function


' ============================================================
' ENCODE IMAGE
' ============================================================

Function EncodeImage(stream:TStream,pixmap:TPixmap,relative:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook)

	Local blocksX:Long
	Local blocksY:Long

	blocksX = (Long(pixmap.width) + 7) / 8
	blocksY = (Long(pixmap.height) + 7) / 8

	WriteImageHeader(stream,relative,pixmap.width,pixmap.height,blocksX,blocksY)

	For Local by:Long = 0 Until blocksY

		For Local bx:Long = 0 Until blocksX

			EncodeBlock(stream,pixmap,Int(bx),Int(by),bookY,bookU,bookV)

		Next

	Next

End Function


' ============================================================
' PREVIEW DECODER
' ============================================================

Function DecodePreview:TPixmap(pixmap:TPixmap,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook)

	Local output:TPixmap

	output = CreatePixmap(pixmap.width,pixmap.height,PF_RGBA8888)

	Local yBlock:Int[]
	Local uBlock:Int[]
	Local vBlock:Int[]
	Local aBlock:Int[]

	yBlock = New Int[64]
	uBlock = New Int[64]
	vBlock = New Int[64]
	aBlock = New Int[64]

	Local blocksX:Long
	Local blocksY:Long

	blocksX = (Long(pixmap.width) + 7) / 8
	blocksY = (Long(pixmap.height) + 7) / 8

	For Local by:Long = 0 Until blocksY

		For Local bx:Long = 0 Until blocksX

			GetBlockY(pixmap,Int(bx),Int(by),yBlock)
			GetBlockU(pixmap,Int(bx),Int(by),uBlock)
			GetBlockV(pixmap,Int(bx),Int(by),vBlock)
			GetBlockA(pixmap,Int(bx),Int(by),aBlock)

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int

			codeY = FindBestCode(bookY,yBlock)
			codeU = FindBestCode(bookU,uBlock)
			codeV = FindBestCode(bookV,vBlock)

			Local residualU:Int[]
			Local residualV:Int[]

			residualU = New Int[4]
			residualV = New Int[4]

			For Local group:Int = 0 Until 4

				Local sumU:Long
				Local sumV:Long

				sumU = 0
				sumV = 0

				Local gx:Int
				Local gy:Int

				gx = (group Mod 2) * 4
				gy = (group / 2) * 4

				For Local yy:Int = gy Until gy + 4

					For Local xx:Int = gx Until gx + 4

						Local p:Int

						p = yy * 8 + xx

						sumU :+ Long(uBlock[p] - GetBookValue(bookU,codeU,p))
						sumV :+ Long(vBlock[p] - GetBookValue(bookV,codeV,p))

					Next

				Next

				residualU[group] = ClampResidual(Int(sumU / 16))
				residualV[group] = ClampResidual(Int(sumV / 16))

			Next

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local p:Int

					p = yy * 8 + xx

					Local yValue:Int
					Local uValue:Int
					Local vValue:Int

					yValue = GetBookValue(bookY,codeY,p)
					yValue :+ ClampResidual(yBlock[p] - yValue)
					yValue :* 2
					yValue = ClampByte(yValue)

					Local group:Int

					group = (yy / 4) * 2 + (xx / 4)

					uValue = GetBookValue(bookU,codeU,p)
					uValue :+ residualU[group]
					uValue :* 2
					uValue = ClampByte(uValue)

					vValue = GetBookValue(bookV,codeV,p)
					vValue :+ residualV[group]
					vValue :* 2
					vValue = ClampByte(vValue)

					Local px:Int
					Local py:Int

					px = Int(bx) * 8 + xx
					py = Int(by) * 8 + yy

					If px < pixmap.width And py < pixmap.height Then

						Local r:Int
						Local g:Int
						Local b:Int

						r = YUVToR(yValue,uValue,vValue)
						g = YUVToG(yValue,uValue,vValue)
						b = YUVToB(yValue,uValue,vValue)

						WritePixel(output,px,py,MakePixel(r,g,b,aBlock[p]))

					EndIf

				Next

			Next

		Next

	Next

	Return output

End Function


' ============================================================
' PREVIEW
' ============================================================

Function ShowPreview(original:TPixmap,decoded:TPixmap,filename:String)

	Local originalImage:TImage
	Local decodedImage:TImage

	originalImage = LoadImage(original)
	decodedImage = LoadImage(decoded)

	If originalImage = Null Then Return
	If decodedImage = Null Then Return

	Local startTime:Int

	startTime = MilliSecs()

	While MilliSecs() - startTime < 5000

		If AppTerminate() Then Exit

		Cls

		SetColor 255,255,255

		DrawText("ENCODER V13 - PREVIEW",30,20)
		DrawText(filename,30,50)

		DrawText("ORIGINAL",30,90)
		DrawText("DESCODIFICADO",990,90)

		DrawImageRect(originalImage,30,120,900,850)
		DrawImageRect(decodedImage,990,120,900,850)

		Flip

		Delay(20)

	Wend

End Function


' ============================================================
' ENCODE FOLDER
'
' No TList.
' Processes images directly from the directory tree.
' ============================================================

Function EncodeFolder(stream:TStream,folder:String,root:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,imageNumber:Long Var,imageCount:Long,previewDone:Int Var)

	Local entries:String[]

	entries = LoadDir(folder,True)

	If entries = Null Then Return

	For Local entry:String = EachIn entries

		If AppTerminate() Then Return

		If entry = "" Then Continue
		If entry = "." Then Continue
		If entry = ".." Then Continue

		Local fullName:String

		fullName = JoinPath(folder,entry)

		Local kind:Int

		kind = FileType(fullName)

		If kind = FILETYPE_DIR Then

			EncodeFolder(stream,fullName,root,bookY,bookU,bookV,imageNumber,imageCount,previewDone)

			Continue

		EndIf

		If kind <> FILETYPE_FILE Then Continue
		If IsImageFile(fullName) = False Then Continue

		Local relative:String

		relative = MakeRelativePath(fullName,root)

		Print ""
		Print "------------------------------------------"
		Print "IMAGEM " + (imageNumber + 1) + " / " + imageCount
		Print relative

		Local pixmap:TPixmap

		pixmap = LoadInputPixmap(fullName)

		If pixmap = Null Then

			Print "ERRO AO CARREGAR. IGNORADA."
			Continue

		EndIf

		Local blocksX:Long
		Local blocksY:Long
		Local totalBlocks:Long

		blocksX = (Long(pixmap.width) + 7) / 8
		blocksY = (Long(pixmap.height) + 7) / 8
		totalBlocks = blocksX * blocksY

		Print "TAMANHO = " + pixmap.width + " x " + pixmap.height
		Print "BLOCOS = " + blocksX + " x " + blocksY
		Print "TOTAL = " + totalBlocks

		EncodeImage(stream,pixmap,relative,bookY,bookU,bookV)

		imageNumber :+ 1

		Print "CODIFICADA."

		If previewDone = False Then

			Print "A CRIAR PREVIEW..."

			Local decoded:TPixmap

			decoded = DecodePreview(pixmap,bookY,bookU,bookV)

			If decoded <> Null Then
				ShowPreview(pixmap,decoded,relative)
			EndIf

			previewDone = True

		EndIf

	Next

End Function


' ============================================================
' DATASET
' ============================================================

Function EncodeDataset(folder:String,quality:Int,datasetName:String)

	Print ""
	Print "=========================================="
	Print "ENCODER V13"
	Print "=========================================="

	Print "FOLDER  = " + folder
	Print "QUALITY = " + quality
	Print "DATASET = " + datasetName


	' ========================================================
	' COUNT
	' ========================================================

	Print ""
	Print "A PROCURAR IMAGENS..."

	Local imageCount:Long

	imageCount = CountImageFiles(folder)

	Print ""
	Print "IMAGENS = " + imageCount

	If imageCount <= 0 Then

		Print ""
		Print "ERRO: nenhuma imagem PNG/JPG/JPEG encontrada."
		Return

	EndIf


	' ========================================================
	' CODEBOOKS
	' ========================================================

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	bookY = CreateCodeBook(CODEBOOK_Y)
	bookU = CreateCodeBook(CODEBOOK_U)
	bookV = CreateCodeBook(CODEBOOK_V)
	bookA = CreateCodeBook(CODEBOOK_A)


	' ========================================================
	' ALPHA
	' ========================================================

	For Local n:Int = 0 Until CODEBOOK_A * BLOCK_PIXELS
		bookA.data[n] = 0
	Next

	bookA.filled = CODEBOOK_A


	' ========================================================
	' TRAIN
	' ========================================================

	Local examined:Long
	Local samples:Long

	examined = 0
	samples = 0

	Print ""
	Print "=========================================="
	Print "TREINO DOS CODEBOOKS"
	Print "=========================================="

	Print "AMOSTRAGEM = 1 / " + TRAIN_SAMPLE
	Print "MAX BLOCOS = " + TRAIN_MAX_BLOCKS
	Print ""

	TrainCodeBooksFolder(folder,bookY,bookU,bookV,examined,samples)

	Print ""
	Print "TREINO TERMINADO"
	Print "BLOCOS EXAMINADOS = " + examined
	Print "AMOSTRAS = " + samples

	FillRemainingBook(bookY)
	FillRemainingBook(bookU)
	FillRemainingBook(bookV)

	Print "CODEBOOK Y = " + bookY.filled
	Print "CODEBOOK U = " + bookU.filled
	Print "CODEBOOK V = " + bookV.filled


	' ========================================================
	' CREATE DATASET
	' ========================================================

	Print ""
	Print "A CRIAR DATASET:"
	Print datasetName

	Local stream:TStream

	stream = WriteStream(datasetName)

	If stream = Null Then

		Print "ERRO: nao conseguiu criar o dataset."
		Return

	EndIf


	' ========================================================
	' HEADER
	' ========================================================

	WriteASCII(stream,"DSET")

	WriteU32LE(stream,Long(HEADER_VERSION))
	WriteU32LE(stream,Long(BLOCK_SIZE))
	WriteU32LE(stream,Long(BLOCK_DATA))

	WriteU32LE(stream,Long(CODEBOOK_Y))
	WriteU32LE(stream,Long(CODEBOOK_U))
	WriteU32LE(stream,Long(CODEBOOK_V))
	WriteU32LE(stream,Long(CODEBOOK_A))

	WriteU32LE(stream,Long(quality))

	WriteU64LE(stream,imageCount)


	' ========================================================
	' SAFE TENSORS
	' ========================================================

	Print "A ESCREVER SAFE TENSORS..."

	WriteASCII(stream,"SAFE")

	WriteSafeTensor(stream,"datasetY",bookY)

	Print "  Y OK"

	WriteSafeTensor(stream,"datasetU",bookU)

	Print "  U OK"

	WriteSafeTensor(stream,"datasetV",bookV)

	Print "  V OK"

	WriteSafeTensor(stream,"datasetA",bookA)

	Print "  A OK"


	' ========================================================
	' IMAGES
	' ========================================================

	WriteASCII(stream,"IMGS")

	Local imageNumber:Long

	imageNumber = 0

	Local previewDone:Int

	previewDone = False


	Print ""
	Print "=========================================="
	Print "A CODIFICAR IMAGENS"
	Print "=========================================="
	Print ""

	EncodeFolder(stream,folder,folder,bookY,bookU,bookV,imageNumber,imageCount,previewDone)


	' ========================================================
	' END
	' ========================================================

	WriteASCII(stream,"END!")

	CloseStream(stream)


	' ========================================================
	' FINAL
	' ========================================================

	Print ""
	Print "=========================================="
	Print "ENCODER V13 TERMINADO"
	Print "=========================================="

	Print "DATASET = " + datasetName
	Print "IMAGENS ENCONTRADAS = " + imageCount
	Print "IMAGENS CODIFICADAS = " + imageNumber

	Print "Y = " + CODEBOOK_Y
	Print "U = " + CODEBOOK_U
	Print "V = " + CODEBOOK_V
	Print "A = " + CODEBOOK_A

	Print "BLOCK DATA = " + BLOCK_DATA
	Print "BLOCK = 8x8"
	Print "ALPHA = RAW LOSSLESS"
	Print "SAFE = EMBUTIDO"
	Print "TREINO MAX = " + TRAIN_MAX_BLOCKS

	Print "=========================================="


	If imageNumber = imageCount Then

		Print ""
		Print "OK: TODAS AS IMAGENS FORAM CODIFICADAS."
		Print "TOTAL = " + imageNumber

	Else

		Print ""
		Print "ATENCAO!"
		Print "ESPERADAS = " + imageCount
		Print "CODIFICADAS = " + imageNumber
		Print "FALTAM = " + (imageCount - imageNumber)

	EndIf

End Function


' ============================================================
' MAIN
'
' V13 CLI:
'
' encoder_v13.exe <folder> <quality> <dataset.dat>
'
' Example:
'
' encoder_v13.exe "D:\images" 90 "D:\dataset.dat"
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "ENCODER V13"
	Print "BLITZMAX NG"
	Print "=========================================="
	Print ""


	Local args:String[]

	args = AppArgs


	If args = Null Then

		Print "ERRO: argumentos nao encontrados."
		Print ""
		Print "Uso:"
		Print "encoder_v13.exe <folder> <quality> <dataset.dat>"
		Print ""
		Return

	EndIf


	If args.Length < 4 Then

		Print "ERRO: argumentos insuficientes."
		Print ""
		Print "Uso:"
		Print "encoder_v13.exe <folder> <quality> <dataset.dat>"
		Print ""
		Print "Exemplo:"
		Print "encoder_v13.exe D:\images 90 D:\dataset.dat"
		Print ""
		Return

	EndIf


	' AppArgs(0) e o nome do executavel.
	' Os argumentos reais começam em AppArgs(1).

	Local folder:String
	Local quality:Int
	Local datasetName:String


	folder = args[1]
	quality = Int(args[2])
	datasetName = args[3]


	' ========================================================
	' VALIDATE FOLDER
	' ========================================================

	If folder = "" Then

		Print "ERRO: folder vazio."
		Return

	EndIf


	If FileType(folder) <> FILETYPE_DIR Then

		Print "ERRO: folder nao existe ou nao e uma pasta."
		Print folder
		Return

	EndIf


	' ========================================================
	' VALIDATE QUALITY
	' ========================================================

	If quality < 0 Then quality = 0
	If quality > 100 Then quality = 100


	' ========================================================
	' DATASET
	' ========================================================

	If datasetName = "" Then

		Print "ERRO: nome do dataset vazio."
		Return

	EndIf


	EncodeDataset(folder,quality,datasetName)


	Print ""
	Print "Processo terminado."

End Function


Main()

EndGraphics
