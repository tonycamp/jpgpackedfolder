SuperStrict

Import BRL.StandardIO
Import BRL.Pixmap
Import BRL.JPGLoader
Import BRL.PNGLoader


' ============================================================
' DATASET DECODER V9
'
' COMPATIVEL COM ENCODER V9
'
' BLOCO:
'   8x8
'
' BLOCO:
'   codeY U16
'   codeU U16
'   codeV U16
'   codeA U16
'
'   Y residual = 64 bytes
'   U residual = 4 bytes
'   V residual = 4 bytes
'   A residual = 64 bytes
'
'   TOTAL:
'
'   8 + 64 + 4 + 4 + 64
'   = 144 bytes
'
' NOTA:
'   O encoder mostrado anteriormente escreve 4 codes U16.
'   Portanto o bloco real desse formato e 144 bytes.
'
' ============================================================


Const BLOCKSIZE:Int = 8
Const BLOCKPIXELS:Int = 64

Const BLOCK_DATA_BYTES:Int = 144

Const HEADER_VERSION:Int = 9


' ============================================================
' IMAGE INFO
' ============================================================

Type TImageInfo

	Field relativePath:String

	Field width:Int
	Field height:Int

	Field blocks:Int

End Type


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int

	Field data:Int[]

End Type


' ============================================================
' CLAMP
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then Return 0

	If value > 255 Then Return 255

	Return value

End Function


' ============================================================
' READ U16
' ============================================================

Function ReadU16LE:Int(stream:TStream)

	Local a:Int
	Local b:Int

	a = ReadByte(stream)
	b = ReadByte(stream)

	Return a | (b Shl 8)

End Function


' ============================================================
' READ U32
' ============================================================

Function ReadU32LE:Int(stream:TStream)

	Local a:Int
	Local b:Int
	Local c:Int
	Local d:Int

	a = ReadByte(stream)
	b = ReadByte(stream)
	c = ReadByte(stream)
	d = ReadByte(stream)

	Return a | (b Shl 8) | (c Shl 16) | (d Shl 24)

End Function


' ============================================================
' READ U64
' ============================================================

Function ReadU64LE:Long(stream:TStream)

	Local value:Long

	value = 0

	For Local i:Int = 0 Until 8

		Local b:Int

		b = ReadByte(stream)

		value = value | (Long(b) Shl (i * 8))

	Next

	Return value

End Function


' ============================================================
' READ ASCII
' ============================================================

Function ReadASCII:String(stream:TStream,length:Int)

	Local result:String

	result = ""

	For Local i:Int = 0 Until length

		Local c:Int

		c = ReadByte(stream)

		If c < 0 Then Exit

		result :+ Chr(c)

	Next

	Return result

End Function


' ============================================================
' READ SIGNED BYTE
'
' Encoder:
'
'   WriteByte(value + 128)
'
' Decoder:
'
'   byte - 128
'
' ============================================================

Function ReadSignedByte:Int(stream:TStream)

	Local value:Int

	value = ReadByte(stream)

	Return value - 128

End Function


' ============================================================
' NORMALIZE PATH
' ============================================================

Function NormalizePath:String(path:String)

	Local result:String

	result = path.Replace("\","/")


	While result.StartsWith("./")

		result = result[2..]

	Wend


	Return result

End Function


' ============================================================
' JOIN PATH
' ============================================================

Function JoinPath:String(folder:String,name:String)

	If folder.EndsWith("/") Then

		Return folder + name

	EndIf


	If folder.EndsWith("\") Then

		Return folder + name

	EndIf


	Return folder + "/" + name

End Function


' ============================================================
' GET FILE NAME
' ============================================================

Function GetFileName:String(path:String)

	Local p:String

	p = NormalizePath(path)


	Local slash:Int

	slash = p.FindLast("/")


	If slash >= 0 Then

		Return p[slash + 1..]

	EndIf


	Return p

End Function


' ============================================================
' GET DIRECTORY
' ============================================================

Function GetDirectory:String(path:String)

	Local p:String

	p = NormalizePath(path)


	Local slash:Int

	slash = p.FindLast("/")


	If slash >= 0 Then

		Return p[..slash]

	EndIf


	Return ""

End Function


' ============================================================
' LOAD CODEBOOK
'
' SafeTensor:
'
' 8 bytes header length
' JSON header
' raw U8 data
'
' ============================================================

Function LoadCodeBook:TCodeBook(stream:TStream,offset:Long,size:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = size

	book.data = New Int[size * BLOCKPIXELS]


	SeekStream(stream,offset)


	Local headerSize:Long

	headerSize = ReadU64LE(stream)


	If headerSize <= 0 Then

		Print "ERRO: header SafeTensor invalido."

		Return book

	EndIf


	If headerSize > 10000000 Then

		Print "ERRO: header SafeTensor demasiado grande."

		Return book

	EndIf


	Local header:String

	header = ReadASCII(stream,Int(headerSize))


	Print "SafeTensor header:"
	Print header


	For Local i:Int = 0 Until book.data.Length

		Local value:Int

		value = ReadByte(stream)

		If value < 0 Then value = 0

		book.data[i] = value

	Next


	Return book

End Function


' ============================================================
' FIND TAG IN DATASET
' ============================================================

Function FindTag:Long(stream:TStream,tag:String)

	Local FileSize:Long

	FileSize = StreamSize(stream)


	If FileSize <= 0 Then Return -1


	SeekStream(stream,0)


	Local tagLength:Int

	tagLength = tag.Length


	If tagLength <= 0 Then Return -1


	For Local pos:Long = 0 Until FileSize - tagLength

		SeekStream(stream,pos)


		Local match:Int

		match = True


		For Local i:Int = 0 Until tagLength

			Local a:Int

			a = ReadByte(stream)


			If a <> (tag[i] & $FF) Then

				match = False

				Exit

			EndIf

		Next


		If match Then

			Return pos

		EndIf

	Next


	Return -1

End Function


' ============================================================
' READ IMAGE HEADER
' ============================================================

Function ReadImageHeader:TImageInfo(stream:TStream)

	Local info:TImageInfo

	info = New TImageInfo


	Local pathLength:Int

	pathLength = ReadU32LE(stream)


	If pathLength < 0 Or pathLength > 1000000 Then

		Print "ERRO: tamanho de caminho invalido."

		Return Null

	EndIf


	info.relativePath = ReadASCII(stream,pathLength)

	info.relativePath = NormalizePath(info.relativePath)


	info.width = ReadU32LE(stream)

	info.height = ReadU32LE(stream)

	info.blocks = ReadU32LE(stream)


	Return info

End Function


' ============================================================
' CALCULATE BLOCKS
' ============================================================

Function CalculateBlocks:Int(width:Int,height:Int)

	Local blocksX:Int
	Local blocksY:Int

	blocksX = width / BLOCKSIZE
	blocksY = height / BLOCKSIZE

	Return blocksX * blocksY

End Function


' ============================================================
' YUV -> RGB
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' DECODE ONE IMAGE
' ============================================================

Function DecodeImage:TPixmap(stream:TStream,info:TImageInfo,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	Print ""
	Print "=========================================="
	Print "DECODIFICAR"
	Print info.relativePath
	Print info.width + " x " + info.height
	Print "=========================================="


	Local output:TPixmap

	output = CreatePixmap(info.width,info.height,PF_RGBA8888)


	If output = Null Then

		Print "ERRO: nao consegui criar pixmap."

		Return Null

	EndIf


	Local quantY:Int
	Local quantC:Int

	quantY = 64 - (qualityLevel * 63 / 100)

	quantC = 96 - (qualityLevel * 95 / 100)


	If quantY < 1 Then quantY = 1

	If quantC < 1 Then quantC = 1


	Print "Quant Y = " + quantY
	Print "Quant C = " + quantC


	Local blocksX:Int
	Local blocksY:Int

	blocksX = info.width / BLOCKSIZE
	blocksY = info.height / BLOCKSIZE


	For Local by:Int = 0 Until blocksY

		For Local bx:Int = 0 Until blocksX


			' ==================================================
			' CODES
			' ==================================================

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int
			Local codeA:Int

			codeY = ReadU16LE(stream)
			codeU = ReadU16LE(stream)
			codeV = ReadU16LE(stream)
			codeA = ReadU16LE(stream)


			If codeY < 0 Or codeY >= bookY.size Then

				codeY = 0

			EndIf


			If codeU < 0 Or codeU >= bookU.size Then

				codeU = 0

			EndIf


			If codeV < 0 Or codeV >= bookV.size Then

				codeV = 0

			EndIf


			If codeA < 0 Or codeA >= bookA.size Then

				codeA = 0

			EndIf


			Local baseY:Int
			Local baseU:Int
			Local baseV:Int
			Local baseA:Int

			baseY = codeY * BLOCKPIXELS
			baseU = codeU * BLOCKPIXELS
			baseV = codeV * BLOCKPIXELS
			baseA = codeA * BLOCKPIXELS


			' ==================================================
			' READ Y RESIDUAL
			' ==================================================

			Local residualY:Int[]

			residualY = New Int[64]


			For Local i:Int = 0 Until 64

				residualY[i] = ReadSignedByte(stream)

			Next


			' ==================================================
			' READ U
			' ==================================================

			Local residualU:Int[]

			residualU = New Int[4]


			For Local i:Int = 0 Until 4

				residualU[i] = ReadSignedByte(stream)

			Next


			' ==================================================
			' READ V
			' ==================================================

			Local residualV:Int[]

			residualV = New Int[4]


			For Local i:Int = 0 Until 4

				residualV[i] = ReadSignedByte(stream)

			Next


			' ==================================================
			' READ ALPHA
			' ==================================================

			Local residualA:Int[]

			residualA = New Int[64]


			For Local i:Int = 0 Until 64

				residualA[i] = ReadSignedByte(stream)

			Next


			' ==================================================
			' RECONSTRUCT PIXELS
			' ==================================================

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local p:Int

					p = yy * 8 + xx


					' ------------------------------------------
					' Y
					' ------------------------------------------

					Local yHalf:Int

					yHalf = bookY.data[baseY + p]

					yHalf :+ residualY[p] * quantY


					' ------------------------------------------
					' U / V
					' ------------------------------------------

					Local ci:Int

					ci = (yy / 4) * 2 + (xx / 4)


					Local uHalf:Int
					Local vHalf:Int

					uHalf = bookU.data[baseU + p]

					vHalf = bookV.data[baseV + p]


					uHalf :+ residualU[ci] * quantC
					vHalf :+ residualV[ci] * quantC


					' ------------------------------------------
					' /2 -> x2
					' ------------------------------------------

					Local yv:Int
					Local uv:Int
					Local vv:Int

					yv = ClampByte(yHalf * 2)

					uv = ClampByte(uHalf * 2)

					vv = ClampByte(vHalf * 2)


					' ------------------------------------------
					' RGB
					' ------------------------------------------

					Local r:Int
					Local g:Int
					Local b:Int

					r = YUVToR(yv,uv,vv)

					g = YUVToG(yv,uv,vv)

					b = YUVToB(yv,uv,vv)


					' ------------------------------------------
					' ALPHA LOSSLESS
					' ------------------------------------------

					Local alpha:Int

					alpha = bookA.data[baseA + p]

					alpha :+ residualA[p]

					alpha = ClampByte(alpha)


					' ------------------------------------------
					' POSITION
					' ------------------------------------------

					Local px:Int
					Local py:Int

					px = bx * BLOCKSIZE + xx
					py = by * BLOCKSIZE + yy


					If px < info.width And py < info.height Then

						Local color:Int

						color = (alpha Shl 24) | (r Shl 16) | (g Shl 8) | b

						WritePixel(output,px,py,color)

					EndIf

				Next

			Next

		Next


		If by Mod 16 = 0 Then

			Print "Linha " + by + " / " + blocksY

		EndIf

	Next


	Return output

End Function


' ============================================================
' SAVE IMAGE WITH ORIGINAL FORMAT
' ============================================================

Function SaveDecodedImage:Int(pix:TPixmap,filename:String,originalPath:String)

	If pix = Null Then

		Print "ERRO: pixmap Null."

		Return 0

	EndIf


	Local extension:String

	extension = originalPath.ToLower()


	' ========================================================
	' JPEG
	' ========================================================

	If extension.EndsWith(".jpg") Or extension.EndsWith(".jpeg") Then

		Print "Formato original = JPEG"

		SavePixmapJPeg(pix,filename,95)

		Return 1

	EndIf


	' ========================================================
	' PNG
	' ========================================================

	If extension.EndsWith(".png") Then

		Print "Formato original = PNG"

		SavePixmapPNG(pix,filename)

		Return 1

	EndIf


	' ========================================================
	' BMP
	' ========================================================

	If extension.EndsWith(".bmp") Then

		Print "Formato original = BMP"

		SavePixmappng(pix,filename)

		Return 1

	EndIf


	' ========================================================
	' DEFAULT
	' ========================================================

	Print "Formato desconhecido."

	Print "A gravar como PNG."

	SavePixmapPNG(pix,filename)

	Return 1

End Function


' ============================================================
' CREATE OUTPUT DIRECTORY
'
' BlitzMax nao possui aqui uma funcao universal simples
' para criar recursivamente todos os diretorios.
'
' O decoder tenta criar a pasta final.
' ============================================================

Function EnsureDirectory(path:String)

	If path = "" Then Return


	If FileType(path) = 2 Then Return


	CreateDir(path)


End Function


' ============================================================
' CREATE DIRECTORY TREE
' ============================================================

Function EnsureDirectoryTree(base:String,relativeDirectory:String)

	If relativeDirectory = "" Then Return


	Local clean:String

	clean = NormalizePath(relativeDirectory)


	Local parts:String[]

	parts = clean.Split("/")


	Local current:String

	current = base


	For Local i:Int = 0 Until parts.Length

		If parts[i] = "" Then Continue


		current = JoinPath(current,parts[i])

		EnsureDirectory(current)

	Next

End Function


' ============================================================
' DECODE DATASET
' ============================================================

Function DecodeDataset(folder:String)

	Local filename:String

	filename = JoinPath(folder,"dataset.dat")


	If Not FileExists(filename) Then

		Print "ERRO: dataset.dat nao encontrado."

		Return

	EndIf


	Print ""
	Print "=========================================="
	Print "DECODER V9"
	Print "=========================================="
	Print filename


	Local stream:TStream

	stream = ReadStream(filename)


	If stream = Null Then

		Print "ERRO ao abrir dataset.dat."

		Return

	EndIf


	' ========================================================
	' MAGIC
	' ========================================================

	Local magic:String

	magic = ReadASCII(stream,4)


	If magic <> "DSET" Then

		Print "ERRO: dataset.dat invalido."

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' HEADER
	' ========================================================

	Local version:Int

	version = ReadU32LE(stream)


	Print "Version = " + version


	If version <> HEADER_VERSION Then

		Print "AVISO: versao diferente de V9."

	EndIf


	Local blockSize:Int

	blockSize = ReadU32LE(stream)


	Local blockBytes:Int

	blockBytes = ReadU32LE(stream)


	Print "Block size = " + blockSize
	Print "Block bytes = " + blockBytes


	If blockSize <> 8 Then

		Print "ERRO: este decoder espera blocos 8x8."

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' CODEBOOK SIZES
	' ========================================================

	Local codebookYSize:Int
	Local codebookUSize:Int
	Local codebookVSize:Int
	Local codebookASize:Int

	codebookYSize = ReadU32LE(stream)

	codebookUSize = ReadU32LE(stream)

	codebookVSize = ReadU32LE(stream)

	codebookASize = ReadU32LE(stream)


	Print "Codebook Y = " + codebookYSize
	Print "Codebook U = " + codebookUSize
	Print "Codebook V = " + codebookVSize
	Print "Codebook A = " + codebookASize


	' ========================================================
	' QUALITY
	' ========================================================

	Local qualityLevel:Int

	qualityLevel = ReadU32LE(stream)


	Print "Quality = " + qualityLevel


	' ========================================================
	' IMAGE COUNT
	' ========================================================

	Local imageCount:Int

	imageCount = ReadU32LE(stream)


	Print "Images = " + imageCount


	If imageCount < 0 Or imageCount > 1000000 Then

		Print "ERRO: numero de imagens invalido."

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' READ IMAGE HEADERS
	' ========================================================

	Local images:TImageInfo[]

	images = New TImageInfo[imageCount]


	For Local i:Int = 0 Until imageCount

		Print ""
		Print "Header imagem " + i + " / " + imageCount


		images[i] = ReadImageHeader(stream)


		If images[i] = Null Then

			Print "ERRO no header."

			CloseStream(stream)

			Return

		EndIf


		Print "Path = " + images[i].relativePath
		Print "Size = " + images[i].width + " x " + images[i].height
		Print "Blocks = " + images[i].blocks


		Local calculated:Int

		calculated = CalculateBlocks(images[i].width,images[i].height)


		If calculated <> images[i].blocks Then

			Print "AVISO: numero de blocos diferente do calculado."

		EndIf

	Next


	' ========================================================
	' SAVE CURRENT POSITION
	'
	' Os blocos comecam imediatamente depois dos headers.
	' ========================================================

	Local blockDataStart:Long

	blockDataStart = StreamPos(stream)


	Print ""
	Print "Block data start = " + blockDataStart


	' ========================================================
	' LOAD EMBEDDED SAFETENSORS
	'
	' Primeiro precisamos descobrir onde estao.
	'
	' Os blocos tem tamanho fixo.
	' ========================================================

	Local totalBlocks:Long

	totalBlocks = 0


	For Local i:Int = 0 Until imageCount

		totalBlocks :+ Long(images[i].blocks)

	Next


	Local allBlockBytes:Long

	allBlockBytes = totalBlocks * Long(BLOCK_DATA_BYTES)


	Local safeStart:Long

	safeStart = blockDataStart + allBlockBytes


	SeekStream(stream,safeStart)


	Local safeMagic:String

	safeMagic = ReadASCII(stream,4)


	If safeMagic <> "SAFE" Then

		Print "ERRO: marcador SAFE nao encontrado."

		Print "Esperado na posicao = " + safeStart
		Print "Encontrado = " + safeMagic

		CloseStream(stream)

		Return

	EndIf


	Print ""
	Print "SAFE encontrado."


	' ========================================================
	' SATY
	' ========================================================

	Local satTag:String

	satTag = ReadASCII(stream,4)

	If satTag <> "SATY" Then

		Print "ERRO: SATY nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	Local satYSize:Long

	satYSize = ReadU64LE(stream)


	Local satYOffset:Long

	satYOffset = StreamPos(stream)


	Print "SATY offset = " + satYOffset
	Print "SATY bytes = " + satYSize


	SeekStream(stream,satYOffset + satYSize)


	' ========================================================
	' SATU
	' ========================================================

	satTag = ReadASCII(stream,4)


	If satTag <> "SATU" Then

		Print "ERRO: SATU nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	Local satUSize:Long

	satUSize = ReadU64LE(stream)


	Local satUOffset:Long

	satUOffset = StreamPos(stream)


	Print "SATU offset = " + satUOffset
	Print "SATU bytes = " + satUSize


	SeekStream(stream,satUOffset + satUSize)


	' ========================================================
	' SATV
	' ========================================================

	satTag = ReadASCII(stream,4)


	If satTag <> "SATV" Then

		Print "ERRO: SATV nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	Local satVSize:Long

	satVSize = ReadU64LE(stream)


	Local satVOffset:Long

	satVOffset = StreamPos(stream)


	Print "SATV offset = " + satVOffset
	Print "SATV bytes = " + satVSize


	SeekStream(stream,satVOffset + satVSize)


	' ========================================================
	' SATA
	' ========================================================

	satTag = ReadASCII(stream,4)


	If satTag <> "SATA" Then

		Print "ERRO: SATA nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	Local satASize:Long

	satASize = ReadU64LE(stream)


	Local satAOffset:Long

	satAOffset = StreamPos(stream)


	Print "SATA offset = " + satAOffset
	Print "SATA bytes = " + satASize


	' ========================================================
	' LOAD CODEBOOKS
	' ========================================================

	Print ""
	Print "A carregar codebook Y..."

	Local bookY:TCodeBook

	bookY = LoadCodeBook(stream,satYOffset,codebookYSize)


	Print "A carregar codebook U..."

	Local bookU:TCodeBook

	bookU = LoadCodeBook(stream,satUOffset,codebookUSize)


	Print "A carregar codebook V..."

	Local bookV:TCodeBook

	bookV = LoadCodeBook(stream,satVOffset,codebookVSize)


	Print "A carregar codebook A..."

	Local bookA:TCodeBook

	bookA = LoadCodeBook(stream,satAOffset,codebookASize)


	' ========================================================
	' DECODE BLOCK DATA
	' ========================================================

	Print ""
	Print "=========================================="
	Print "A DESCODIFICAR IMAGENS"
	Print "=========================================="


	SeekStream(stream,blockDataStart)


	For Local i:Int = 0 Until imageCount

		Local info:TImageInfo

		info = images[i]


		Print ""
		Print "Imagem " + (i + 1) + " / " + imageCount


		Local reconstructed:TPixmap

		reconstructed = DecodeImage(stream,info,bookY,bookU,bookV,bookA,qualityLevel)


		If reconstructed = Null Then

			Print "ERRO ao reconstruir."

			Continue

		EndIf


		' ====================================================
		' OUTPUT DIRECTORY
		' ====================================================

		Local relativeDirectory:String

		relativeDirectory = GetDirectory(info.relativePath)


		If relativeDirectory <> "" Then

			EnsureDirectoryTree(folder,relativeDirectory)

		EndIf


		Local outputPath:String

		outputPath = JoinPath(folder,info.relativePath)


		Print "A gravar:"
		Print outputPath


		If SaveDecodedImage(reconstructed,outputPath,info.relativePath) = 1 Then

			Print "OK"

		Else

			Print "ERRO ao gravar."

		EndIf

	Next


	CloseStream(stream)


	Print ""
	Print "=========================================="
	Print "DECODER V9 TERMINADO"
	Print "=========================================="


End Function


' ============================================================
' MAIN
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DATASET DECODER V9"
	Print "8x8 RGBA + ALPHA"
	Print "=========================================="
	Print ""


	Local folder:String

	folder = Input("Folder onde esta o dataset.dat: ")


	If folder = "" Then

		Print "Folder vazio."

		Return

	EndIf


	DecodeDataset(folder)


	Print ""
	Print "Prima ESC para sair."


	Repeat

		Delay(20)

	Until KeyHit(KEY_ESCAPE)

End Function


Main()