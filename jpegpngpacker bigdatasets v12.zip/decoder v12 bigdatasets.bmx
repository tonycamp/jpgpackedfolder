SuperStrict

Import BRL.StandardIO
Import BRL.FileSystem
Import BRL.Pixmap
Import BRL.PNGLoader
Import BRL.Graphics
Import BRL.Max2D


Graphics 1920,1080


Const HEADER_VERSION:Int = 12
Const BLOCK_SIZE:Int = 8
Const BLOCK_PIXELS:Int = 64
Const BLOCK_DATA:Int = 144

Const CODEBOOK_Y:Int = 4096
Const CODEBOOK_U:Int = 1024
Const CODEBOOK_V:Int = 1024
Const CODEBOOK_A:Int = 256


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int
	Field data:Byte[]

End Type


Function CreateCodeBook:TCodeBook(size:Int)

	Local book:TCodeBook

	book = New TCodeBook
	book.size = size
	book.data = New Byte[size * BLOCK_PIXELS]

	Return book

End Function


Function ByteValue:Int(value:Byte)

	Return Int(value) & $FF

End Function


Function GetBookValue:Int(book:TCodeBook,code:Int,pos:Int)

	If code < 0 Then Return 0
	If code >= book.size Then Return 0
	If pos < 0 Then Return 0
	If pos >= BLOCK_PIXELS Then Return 0

	Return ByteValue(book.data[code * BLOCK_PIXELS + pos])

End Function


' ============================================================
' UTIL
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then value = 0
	If value > 255 Then value = 255

	Return value

End Function


Function MakePixel:Int(r:Int,g:Int,b:Int,a:Int)

	r = ClampByte(r)
	g = ClampByte(g)
	b = ClampByte(b)
	a = ClampByte(a)

	Return (a Shl 24) | (r Shl 16) | (g Shl 8) | b

End Function


Function JoinPath:String(folder:String,name:String)

	Local result:String

	result = folder

	If result.EndsWith("/") = False And result.EndsWith("\") = False Then
		result :+ "/"
	EndIf

	result :+ name

	Return result

End Function


' ============================================================
' STREAM READ
' ============================================================

Function ReadU8:Int(stream:TStream)

	Return stream.ReadByte() & $FF

End Function


Function ReadU16LE:Int(stream:TStream)

	Local a:Int
	Local b:Int

	a = ReadU8(stream)
	b = ReadU8(stream)

	Return a | (b Shl 8)

End Function


Function ReadU32LE:Long(stream:TStream)

	Local a:Long
	Local b:Long
	Local c:Long
	Local d:Long

	a = Long(ReadU8(stream))
	b = Long(ReadU8(stream))
	c = Long(ReadU8(stream))
	d = Long(ReadU8(stream))

	Return a | (b Shl 8) | (c Shl 16) | (d Shl 24)

End Function


Function ReadU64LE:Long(stream:TStream)

	Local result:Long

	result = 0

	For Local n:Int = 0 Until 8

		Local value:Long

		value = Long(ReadU8(stream))

		result :+ value Shl (n * 8)

	Next

	Return result

End Function


Function ReadASCII:String(stream:TStream,length:Int)

	Local result:String

	result = ""

	For Local n:Int = 0 Until length

		Local value:Int

		value = ReadU8(stream)

		result :+ Chr(value)

	Next

	Return result

End Function


' ============================================================
' SAFE TENSOR
'
' Encoder:
'
' SAFE
' U64 tensor byte count
' U32 name length
' name
' U32 element count
' raw bytes
' ============================================================

Function ReadSafeTensor:Int(stream:TStream,book:TCodeBook,expectedName:String)

	Local magic:String

	magic = ReadASCII(stream,4)

	If magic <> "SAFE" Then

		Print "ERRO: SAFE tensor invalido."
		Print "Esperado SAFE."
		Print "Recebido " + magic

		Return False

	EndIf


	Local tensorBytes:Long

	tensorBytes = ReadU64LE(stream)


	Local nameLength:Long

	nameLength = ReadU32LE(stream)

	If nameLength < 0 Or nameLength > 1048576 Then

		Print "ERRO: nome do tensor invalido."

		Return False

	EndIf


	Local tensorName:String

	tensorName = ReadASCII(stream,Int(nameLength))

	If tensorName <> expectedName Then

		Print "ERRO: tensor inesperado."
		Print "Esperado = " + expectedName
		Print "Recebido = " + tensorName

		Return False

	EndIf


	Local elementCount:Long

	elementCount = ReadU32LE(stream)


	If elementCount <> Long(book.size) Then

		Print "ERRO: quantidade de elementos invalida."
		Print "Tensor = " + tensorName
		Print "Esperado = " + book.size
		Print "Recebido = " + elementCount

		Return False

	EndIf


	Local expectedBytes:Long

	expectedBytes = Long(book.size) * Long(BLOCK_PIXELS)


	If tensorBytes <> expectedBytes Then

		Print "ERRO: tamanho do tensor invalido."
		Print "Tensor = " + tensorName
		Print "Esperado = " + expectedBytes
		Print "Recebido = " + tensorBytes

		Return False

	EndIf


	For Local n:Long = 0 Until tensorBytes

		book.data[Int(n)] = Byte(ReadU8(stream))

	Next


	Print "SAFE OK: " + tensorName
	Print "ELEMENTOS = " + elementCount
	Print "BYTES = " + tensorBytes

	Return True

End Function


' ============================================================
' READ CODEBOOKS
' ============================================================

Function LoadCodeBooks:Int(stream:TStream,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook)

	Print ""
	Print "=========================================="
	Print "SAFE TENSORS"
	Print "=========================================="


	Local result:Int

	result = ReadSafeTensor(stream,bookY,"datasetY")

	If result = False Then Return False


	result = ReadSafeTensor(stream,bookU,"datasetU")

	If result = False Then Return False


	result = ReadSafeTensor(stream,bookV,"datasetV")

	If result = False Then Return False


	result = ReadSafeTensor(stream,bookA,"datasetA")

	If result = False Then Return False


	Return True

End Function


' ============================================================
' YUV TO RGB
'
' Mesmo cálculo usado pelo encoder.
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)
	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)
	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' IMAGE HEADER
'
' Encoder:
'
' U32 relative length
' relative
' U32 width
' U32 height
' U32 blocksX
' U32 blocksY
' U64 block count
' ============================================================

Function ReadImageHeader:Int(stream:TStream,relative:String Var,width:Int Var,height:Int Var,blocksX:Long Var,blocksY:Long Var,blockCount:Long Var)

	Local nameLength:Long

	nameLength = ReadU32LE(stream)

	If nameLength < 0 Or nameLength > 16777216 Then

		Print "ERRO: comprimento de nome invalido."

		Return False

	EndIf


	relative = ReadASCII(stream,Int(nameLength))

	width = Int(ReadU32LE(stream))
	height = Int(ReadU32LE(stream))

	blocksX = ReadU32LE(stream)
	blocksY = ReadU32LE(stream)

	blockCount = ReadU64LE(stream)


	Local calculated:Long

	calculated = blocksX * blocksY

	If blockCount <> calculated Then

		Print "ERRO: quantidade de blocos inconsistente."
		Print "Header = " + blockCount
		Print "Calculado = " + calculated

		Return False

	EndIf


	If width <= 0 Or height <= 0 Then

		Print "ERRO: dimensoes invalidas."

		Return False

	EndIf


	If blocksX <= 0 Or blocksY <= 0 Then

		Print "ERRO: dimensao de blocos invalida."

		Return False

	EndIf


	Return True

End Function


' ============================================================
' DECODE BLOCK
'
' Estrutura exata:
'
' 2 bytes codeY
' 2 bytes codeU
' 2 bytes codeV
' 2 bytes codeA
'
' 64 bytes Y residual
' 4 bytes U residual
' 4 bytes V residual
' 64 bytes Alpha RAW
'
' = 144 bytes
' ============================================================

Function DecodeBlock(stream:TStream,pixmap:TPixmap,bx:Long,by:Long,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook)

	Local codeY:Int
	Local codeU:Int
	Local codeV:Int
	Local codeA:Int

	codeY = ReadU16LE(stream)
	codeU = ReadU16LE(stream)
	codeV = ReadU16LE(stream)
	codeA = ReadU16LE(stream)


	If codeY >= bookY.size Then
		Print "ERRO: codeY invalido."
		Return
	EndIf

	If codeU >= bookU.size Then
		Print "ERRO: codeU invalido."
		Return
	EndIf

	If codeV >= bookV.size Then
		Print "ERRO: codeV invalido."
		Return
	EndIf


	Local yResidual:Int[]
	Local uResidual:Int[]
	Local vResidual:Int[]
	Local alpha:Int[]

	yResidual = New Int[64]
	uResidual = New Int[4]
	vResidual = New Int[4]
	alpha = New Int[64]


	' --------------------------------------------------------
	' Y RESIDUAL
	' --------------------------------------------------------

	For Local p:Int = 0 Until 64

		Local value:Int

		value = ReadU8(stream)

		yResidual[p] = value - 128

	Next


	' --------------------------------------------------------
	' U RESIDUAL 4x4
	' --------------------------------------------------------

	For Local group:Int = 0 Until 4

		uResidual[group] = ReadU8(stream) - 128

	Next


	' --------------------------------------------------------
	' V RESIDUAL 4x4
	' --------------------------------------------------------

	For Local group:Int = 0 Until 4

		vResidual[group] = ReadU8(stream) - 128

	Next


	' --------------------------------------------------------
	' ALPHA RAW LOSSLESS
	' --------------------------------------------------------

	For Local p:Int = 0 Until 64

		alpha[p] = ReadU8(stream)

	Next


	' --------------------------------------------------------
	' RECONSTRUCAO
	' --------------------------------------------------------

	For Local yy:Int = 0 Until BLOCK_SIZE

		For Local xx:Int = 0 Until BLOCK_SIZE

			Local p:Int

			p = yy * BLOCK_SIZE + xx


			' ------------------------------------------------
			' Y
			' ------------------------------------------------

			Local yValue:Int

			yValue = GetBookValue(bookY,codeY,p)
			yValue :+ yResidual[p]
			yValue :* 2
			yValue = ClampByte(yValue)


			' ------------------------------------------------
			' GRUPO U/V
			' ------------------------------------------------

			Local group:Int

			group = (yy / 4) * 2 + (xx / 4)


			' ------------------------------------------------
			' U
			' ------------------------------------------------

			Local uValue:Int

			uValue = GetBookValue(bookU,codeU,p)
			uValue :+ uResidual[group]
			uValue :* 2
			uValue = ClampByte(uValue)


			' ------------------------------------------------
			' V
			' ------------------------------------------------

			Local vValue:Int

			vValue = GetBookValue(bookV,codeV,p)
			vValue :+ vResidual[group]
			vValue :* 2
			vValue = ClampByte(vValue)


			' ------------------------------------------------
			' RGB
			' ------------------------------------------------

			Local r:Int
			Local g:Int
			Local b:Int

			r = YUVToR(yValue,uValue,vValue)
			g = YUVToG(yValue,uValue,vValue)
			b = YUVToB(yValue,uValue,vValue)


			' ------------------------------------------------
			' POSICAO
			' ------------------------------------------------

			Local px:Long
			Local py:Long

			px = bx * 8 + xx
			py = by * 8 + yy


			If px < Long(pixmap.width) And py < Long(pixmap.height) Then

				WritePixel(pixmap,Int(px),Int(py),MakePixel(r,g,b,alpha[p]))

			EndIf

		Next

	Next

End Function


' ============================================================
' DECODE IMAGE
' ============================================================

Function DecodeImage:Int(stream:TStream,outputFolder:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook)

	Local relative:String
	Local width:Int
	Local height:Int
	Local blocksX:Long
	Local blocksY:Long
	Local blockCount:Long


	Local result:Int

	result = ReadImageHeader(stream,relative,width,height,blocksX,blocksY,blockCount)

	If result = False Then Return False


	Print ""
	Print "------------------------------------------"
	Print "IMAGEM"
	Print relative
	Print "TAMANHO = " + width + " x " + height
	Print "BLOCOS = " + blocksX + " x " + blocksY
	Print "TOTAL = " + blockCount


	Local pixmap:TPixmap

	pixmap = CreatePixmap(width,height,PF_RGBA8888)

	If pixmap = Null Then

		Print "ERRO: nao conseguiu criar pixmap."

		Return False

	EndIf


	' --------------------------------------------------------
	' DECODIFICA TODOS OS BLOCOS
	' --------------------------------------------------------

	Local decodedBlocks:Long

	decodedBlocks = 0


	For Local by:Long = 0 Until blocksY

		For Local bx:Long = 0 Until blocksX

			DecodeBlock(stream,pixmap,bx,by,bookY,bookU,bookV)

			decodedBlocks :+ 1

		Next

	Next


	If decodedBlocks <> blockCount Then

		Print "ERRO: blocos descodificados inconsistentes."

		Return False

	EndIf


	' --------------------------------------------------------
	' NOME DE SAIDA
	'
	' O caminho relativo original é mantido.
	' A extensão passa para PNG.
	' --------------------------------------------------------

	Local outputRelative:String

	outputRelative = relative

	Local lowerName:String

	lowerName = outputRelative.ToLower()


	If lowerName.EndsWith(".jpeg") Then

		outputRelative = outputRelative[..outputRelative.Length - 5] + ".png"

	ElseIf lowerName.EndsWith(".jpg") Then

		outputRelative = outputRelative[..outputRelative.Length - 4] + ".png"

	ElseIf lowerName.EndsWith(".png") Then

		outputRelative = outputRelative[..outputRelative.Length - 4] + ".decoded.png"

	Else

		outputRelative :+ ".png"

	EndIf


	' --------------------------------------------------------
	' CAMINHO FINAL
	' --------------------------------------------------------

	Local outputName:String

	outputName = JoinPath(outputFolder,outputRelative)


	' --------------------------------------------------------
	' CRIAR PASTAS NECESSARIAS
	' --------------------------------------------------------

	Local slashPos:Int

	slashPos = outputName.FindLast("/")

	If slashPos >= 0 Then

		Local outputDirectory:String

		outputDirectory = outputName[..slashPos]

		If outputDirectory <> "" Then

			CreateDir(outputDirectory,True)

		EndIf

	EndIf


	' --------------------------------------------------------
	' GRAVAR PNG
	' --------------------------------------------------------

	Print "A gravar:"
	Print outputName

	Local saveResult:Int

	saveResult = SavePixmapPNG(pixmap,outputName)

	If saveResult = False Then

		Print "ERRO: falhou ao gravar PNG."

		Return False

	EndIf


	Print "DESCODIFICADA OK."

	Return True

End Function


' ============================================================
' DATASET DECODER
' ============================================================

Function DecodeDataset(datasetName:String)

	Print ""
	Print "=========================================="
	Print "DECODER V12"
	Print "BLITZMAX NG"
	Print "=========================================="

	Print "DATASET = " + datasetName


	' --------------------------------------------------------
	' ABRIR DATASET
	' --------------------------------------------------------

	Local stream:TStream

	stream = ReadStream(datasetName)

	If stream = Null Then

		Print "ERRO: nao conseguiu abrir dataset.dat."

		Return

	EndIf


	' --------------------------------------------------------
	' MAIN MAGIC
	' --------------------------------------------------------

	Local magic:String

	magic = ReadASCII(stream,4)

	If magic <> "DSET" Then

		Print "ERRO: ficheiro nao e um DSET."

		CloseStream(stream)

		Return

	EndIf


	Print "MAGIC = DSET"


	' --------------------------------------------------------
	' HEADER
	' --------------------------------------------------------

	Local version:Long
	Local blockSize:Long
	Local blockData:Long

	Local codebookY:Long
	Local codebookU:Long
	Local codebookV:Long
	Local codebookA:Long

	Local quality:Long
	Local imageCount:Long


	version = ReadU32LE(stream)
	blockSize = ReadU32LE(stream)
	blockData = ReadU32LE(stream)

	codebookY = ReadU32LE(stream)
	codebookU = ReadU32LE(stream)
	codebookV = ReadU32LE(stream)
	codebookA = ReadU32LE(stream)

	quality = ReadU32LE(stream)

	imageCount = ReadU64LE(stream)


	Print "VERSION = " + version
	Print "BLOCK SIZE = " + blockSize
	Print "BLOCK DATA = " + blockData
	Print "CODEBOOK Y = " + codebookY
	Print "CODEBOOK U = " + codebookU
	Print "CODEBOOK V = " + codebookV
	Print "CODEBOOK A = " + codebookA
	Print "QUALITY = " + quality
	Print "IMAGENS = " + imageCount


	' --------------------------------------------------------
	' VALIDACAO
	' --------------------------------------------------------

	If version <> HEADER_VERSION Then

		Print "ERRO: versao nao suportada."

		CloseStream(stream)

		Return

	EndIf


	If blockSize <> BLOCK_SIZE Then

		Print "ERRO: BLOCK SIZE invalido."

		CloseStream(stream)

		Return

	EndIf


	If blockData <> BLOCK_DATA Then

		Print "ERRO: BLOCK DATA invalido."

		CloseStream(stream)

		Return

	EndIf


	If codebookY <> CODEBOOK_Y Then

		Print "ERRO: CODEBOOK Y invalido."

		CloseStream(stream)

		Return

	EndIf


	If codebookU <> CODEBOOK_U Then

		Print "ERRO: CODEBOOK U invalido."

		CloseStream(stream)

		Return

	EndIf


	If codebookV <> CODEBOOK_V Then

		Print "ERRO: CODEBOOK V invalido."

		CloseStream(stream)

		Return

	EndIf


	If codebookA <> CODEBOOK_A Then

		Print "ERRO: CODEBOOK A invalido."

		CloseStream(stream)

		Return

	EndIf


	If imageCount <= 0 Then

		Print "ERRO: dataset sem imagens."

		CloseStream(stream)

		Return

	EndIf


	' --------------------------------------------------------
	' CRIAR CODEBOOKS
	' --------------------------------------------------------

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	bookY = CreateCodeBook(CODEBOOK_Y)
	bookU = CreateCodeBook(CODEBOOK_U)
	bookV = CreateCodeBook(CODEBOOK_V)
	bookA = CreateCodeBook(CODEBOOK_A)


	' --------------------------------------------------------
	' SAFE MARKER
	' --------------------------------------------------------

	Local safeMarker:String

	safeMarker = ReadASCII(stream,4)

	If safeMarker <> "SAFE" Then

		Print "ERRO: marcador SAFE nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	' --------------------------------------------------------
	' SAFE TENSORS
	' --------------------------------------------------------

	Local safeResult:Int

	safeResult = LoadCodeBooks(stream,bookY,bookU,bookV,bookA)

	If safeResult = False Then

		Print "ERRO: falha ao carregar SafeTensors."

		CloseStream(stream)

		Return

	EndIf


	' --------------------------------------------------------
	' IMGS MARKER
	' --------------------------------------------------------

	Local imageMarker:String

	imageMarker = ReadASCII(stream,4)

	If imageMarker <> "IMGS" Then

		Print "ERRO: marcador IMGS nao encontrado."

		CloseStream(stream)

		Return

	EndIf


	' --------------------------------------------------------
	' OUTPUT
	' --------------------------------------------------------

	Local outputFolder:String

	outputFolder = "decoded"

	CreateDir(outputFolder,True)


	Print ""
	Print "=========================================="
	Print "DESCODIFICACAO"
	Print "=========================================="

	Print "OUTPUT = " + outputFolder


	' --------------------------------------------------------
	' IMAGENS
	' --------------------------------------------------------

	Local decodedCount:Long

	decodedCount = 0


	For Local imageIndex:Long = 0 Until imageCount

		Print ""
		Print "IMAGEM " + (imageIndex + 1) + " / " + imageCount


		Local result:Int

		result = DecodeImage(stream,outputFolder,bookY,bookU,bookV)

		If result = False Then

			Print "ERRO NA IMAGEM " + (imageIndex + 1)

			Exit

		EndIf


		decodedCount :+ 1


		If AppTerminate() Then Exit

	Next


	' --------------------------------------------------------
	' END MARKER
	' --------------------------------------------------------

	If decodedCount = imageCount Then

		Local endMarker:String

		endMarker = ReadASCII(stream,4)

		If endMarker = "END!" Then

			Print ""
			Print "END! OK"

		Else

			Print ""
			Print "AVISO: END! nao encontrado."
			Print "Recebido = " + endMarker

		EndIf

	EndIf


	CloseStream(stream)


	' --------------------------------------------------------
	' FINAL
	' --------------------------------------------------------

	Print ""
	Print "=========================================="
	Print "DECODER V12 TERMINADO"
	Print "=========================================="

	Print "IMAGENS NO HEADER = " + imageCount
	Print "IMAGENS DESCODIFICADAS = " + decodedCount
	Print "OUTPUT = " + outputFolder
	Print "ALPHA = RAW LOSSLESS"
	Print "BLOCK = 8x8"
	Print "SAFE = LIDO DO DATASET"
	Print "=========================================="

End Function


' ============================================================
' MAIN
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DECODER V12"
	Print "BLITZMAX NG 1.56"
	Print "=========================================="
	Print ""

	Local datasetName:String

	datasetName = Input("Dataset DAT: ")


	If datasetName <> "" Then

		DecodeDataset(datasetName)

	Else

		Print "Dataset vazio."

	EndIf


	Print ""
	Print "Processo terminado."

End Function


Main()


' ============================================================
' FIM
' ============================================================

EndGraphics