SuperStrict

Import BRL.StandardIO
Import BRL.Pixmap
Import BRL.PNGLoader
Import BRL.JPGLoader

Graphics 1920,1080

Const BLOCKSIZE:Int = 8
Const BLOCKPIXELS:Int = 64
Const HEADERVERSION:Int = 12


' ============================================================
' READER
' ============================================================

Type TReader

	Field stream:TStream
	Field ok:Int

End Type


Function CreateReader:TReader(stream:TStream)

	Local reader:TReader

	reader = New TReader
	reader.stream = stream
	reader.ok = True

	Return reader

End Function


' ============================================================
' READ BYTE
' ============================================================

Function ReadByteSafe:Int(reader:TReader)

	If reader.ok = False Then Return 0

	Local value:Int

	value = ReadByte(reader.stream)

	If value < 0 Then

		reader.ok = False
		Return 0

	EndIf

	Return value

End Function


' ============================================================
' READ U16
' ============================================================

Function ReadU16LE:Int(reader:TReader)

	Local a:Int
	Local b:Int

	a = ReadByteSafe(reader)
	b = ReadByteSafe(reader)

	Return a | (b Shl 8)

End Function


' ============================================================
' READ U32
' ============================================================

Function ReadU32LE:Long(reader:TReader)

	Local a:Long
	Local b:Long
	Local c:Long
	Local d:Long

	a = ReadByteSafe(reader)
	b = ReadByteSafe(reader)
	c = ReadByteSafe(reader)
	d = ReadByteSafe(reader)

	Return a | (b Shl 8) | (c Shl 16) | (d Shl 24)

End Function


' ============================================================
' READ U64
' ============================================================

Function ReadU64LE:Long(reader:TReader)

	Local value:Long

	value = 0

	For Local i:Int = 0 Until 8

		Local b:Long

		b = ReadByteSafe(reader)

		value = value | (b Shl (i * 8))

	Next

	Return value

End Function


' ============================================================
' READ ASCII
' ============================================================

Function ReadASCII:String(reader:TReader,count:Int)

	Local text:String

	text = ""

	If count < 0 Then

		reader.ok = False
		Return ""

	EndIf

	For Local i:Int = 0 Until count

		Local c:Int

		c = ReadByteSafe(reader)

		If reader.ok = False Then Return ""

		text :+ Chr(c)

	Next

	Return text

End Function


' ============================================================
' READ FOURCC
' ============================================================

Function ReadFourCC:String(reader:TReader)

	Local a:Int
	Local b:Int
	Local c:Int
	Local d:Int

	a = ReadByteSafe(reader)
	b = ReadByteSafe(reader)
	c = ReadByteSafe(reader)
	d = ReadByteSafe(reader)

	If reader.ok = False Then Return ""

	Return Chr(a) + Chr(b) + Chr(c) + Chr(d)

End Function


' ============================================================
' FOURCC PARA U32
'
' Os 4 bytes ja foram lidos.
' ============================================================

Function FourCCToU32:Long(text:String)

	If text.Length <> 4 Then Return 0

	Local a:Long
	Local b:Long
	Local c:Long
	Local d:Long

	a = text[0] & $FF
	b = text[1] & $FF
	c = text[2] & $FF
	d = text[3] & $FF

	Return a | (b Shl 8) | (c Shl 16) | (d Shl 24)

End Function


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int
	Field data:Byte[]

End Type


Function CreateCodeBook:TCodeBook(size:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = size
	book.data = New Byte[size * BLOCKPIXELS]

	Return book

End Function


' ============================================================
' BYTE VALUE
' ============================================================

Function ByteValue:Int(value:Byte)

	Return Int(value) & $FF

End Function


' ============================================================
' CLAMP
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then Return 0

	If value > 255 Then Return 255

	Return value

End Function


' ============================================================
' JOIN PATH
' ============================================================

Function JoinPath:String(folder:String,name:String)

	If folder.EndsWith("/") Then

		Return folder + name

	EndIf

	If folder.EndsWith("\") Then

		Return folder + name

	EndIf

	Return folder + "/" + name

End Function


' ============================================================
' YUV TO RGB
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' MAKE PIXEL
' ============================================================

Function MakePixel:Int(r:Int,g:Int,b:Int,a:Int)

	r = ClampByte(r)
	g = ClampByte(g)
	b = ClampByte(b)
	a = ClampByte(a)

	Return (a Shl 24) | (r Shl 16) | (g Shl 8) | b

End Function


' ============================================================
' CODEBOOK VALUE
' ============================================================

Function GetBookValue:Int(book:TCodeBook,code:Int,pos:Int)

	If book = Null Then Return 0

	If code < 0 Then Return 0

	If code >= book.size Then Return 0

	If pos < 0 Then Return 0

	If pos >= BLOCKPIXELS Then Return 0

	Local index:Int

	index = code * BLOCKPIXELS + pos

	If index < 0 Then Return 0

	If index >= book.data.Length Then Return 0

	Return ByteValue(book.data[index])

End Function


' ============================================================
' LOAD SAFETENSOR
' ============================================================

Function LoadSafeTensor:TCodeBook(filename:String,expectedSize:Int)

	Print "A carregar " + filename

	If Not FileExists(filename) Then

		Print "ERRO: ficheiro nao existe."

		Return Null

	EndIf

	Local stream:TStream

	stream = ReadStream(filename)

	If stream = Null Then

		Print "ERRO: nao abriu SafeTensor."

		Return Null

	EndIf

	Local reader:TReader

	reader = CreateReader(stream)

	Local headerSize:Long

	headerSize = ReadU64LE(reader)

	If reader.ok = False Then

		Print "ERRO: falha a ler header."

		CloseStream(stream)

		Return Null

	EndIf

	If headerSize <= 0 Or headerSize > 1000000 Then

		Print "ERRO: header SafeTensor invalido."

		CloseStream(stream)

		Return Null

	EndIf

	Local header:String

	header = ReadASCII(reader,Int(headerSize))

	If reader.ok = False Then

		Print "ERRO: header incompleto."

		CloseStream(stream)

		Return Null

	EndIf

	Local book:TCodeBook

	book = CreateCodeBook(expectedSize)

	Local dataBytes:Long

	dataBytes = Long(expectedSize) * Long(BLOCKPIXELS)

	If dataBytes > book.data.Length Then

		CloseStream(stream)

		Return Null

	EndIf

	For Local i:Long = 0 Until dataBytes

		Local value:Int

		value = ReadByteSafe(reader)

		If reader.ok = False Then

			Print "ERRO: SafeTensor terminou antes do esperado."

			CloseStream(stream)

			Return Null

		EndIf

		book.data[Int(i)] = Byte(value)

	Next

	CloseStream(stream)

	Print "SafeTensor OK"

	Return book

End Function


' ============================================================
' DECODE IMAGE
' ============================================================

Function DecodeImage:TPixmap(reader:TReader,width:Int,height:Int,blocksX:Int,blocksY:Int,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	If width <= 0 Or height <= 0 Then

		Print "ERRO: dimensoes invalidas."

		Return Null

	EndIf

	If blocksX <= 0 Or blocksY <= 0 Then

		Print "ERRO: blocos invalidos."

		Return Null

	EndIf

	Local expectedX:Int
	Local expectedY:Int

	expectedX = (width + 7) / 8
	expectedY = (height + 7) / 8

	If blocksX <> expectedX Or blocksY <> expectedY Then

		Print "ERRO: numero de blocos nao corresponde a imagem."

		Return Null

	EndIf

	Local pix:TPixmap

	pix = CreatePixmap(width,height,PF_RGBA8888)

	If pix = Null Then

		Print "ERRO: nao criou pixmap."

		Return Null

	EndIf

	Local blockY:Int[]
	Local blockU:Int[]
	Local blockV:Int[]
	Local blockA:Int[]

	blockY = New Int[64]
	blockU = New Int[64]
	blockV = New Int[64]
	blockA = New Int[64]

	For Local by:Int = 0 Until blocksY

		For Local bx:Int = 0 Until blocksX

			If reader.ok = False Then

				Print "ERRO: fim inesperado."

				Return Null

			EndIf

			' ==================================================
			' CODES
			' ==================================================

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int
			Local codeA:Int

			codeY = ReadU16LE(reader)
			codeU = ReadU16LE(reader)
			codeV = ReadU16LE(reader)
			codeA = ReadU16LE(reader)

			If reader.ok = False Then

				Print "ERRO: header do bloco incompleto."

				Return Null

			EndIf

			If codeY >= bookY.size Then

				Print "ERRO: code Y invalido = " + codeY

				Return Null

			EndIf

			If codeU >= bookU.size Then

				Print "ERRO: code U invalido = " + codeU

				Return Null

			EndIf

			If codeV >= bookV.size Then

				Print "ERRO: code V invalido = " + codeV

				Return Null

			EndIf

			If codeA >= bookA.size Then

				Print "ERRO: code A invalido = " + codeA

				Return Null

			EndIf

			' ==================================================
			' Y RESIDUAL
			' ==================================================

			For Local i:Int = 0 Until 64

				Local value:Int

				value = ReadByteSafe(reader)

				If reader.ok = False Then

					Print "ERRO: residual Y incompleto."

					Return Null

				EndIf

				blockY[i] = value - 128

			Next

			' ==================================================
			' U RESIDUAL
			' ==================================================

			Local residualU:Int[]

			residualU = New Int[4]

			For Local i:Int = 0 Until 4

				residualU[i] = ReadByteSafe(reader) - 128

				If reader.ok = False Then

					Print "ERRO: residual U incompleto."

					Return Null

				EndIf

			Next

			' ==================================================
			' V RESIDUAL
			' ==================================================

			Local residualV:Int[]

			residualV = New Int[4]

			For Local i:Int = 0 Until 4

				residualV[i] = ReadByteSafe(reader) - 128

				If reader.ok = False Then

					Print "ERRO: residual V incompleto."

					Return Null

				EndIf

			Next

			' ==================================================
			' ALPHA
			' ==================================================

			For Local i:Int = 0 Until 64

				blockA[i] = ReadByteSafe(reader)

				If reader.ok = False Then

					Print "ERRO: alpha incompleto."

					Return Null

				EndIf

			Next

			' ==================================================
			' RECONSTRUCAO
			' ==================================================

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local p:Int

					p = yy * 8 + xx

					' ------------------------------------------
					' Y
					' ------------------------------------------

					Local baseY:Int

					baseY = GetBookValue(bookY,codeY,p)

					Local yValue:Int

					yValue = baseY + blockY[p]

					yValue = yValue * 2

					yValue = ClampByte(yValue)

					' ------------------------------------------
					' U
					' ------------------------------------------

					Local uGroup:Int

					uGroup = (yy / 4) * 2 + (xx / 4)

					Local baseU:Int

					baseU = GetBookValue(bookU,codeU,p)

					Local uValue:Int

					uValue = baseU + residualU[uGroup]

					uValue = uValue * 2

					uValue = ClampByte(uValue)

					' ------------------------------------------
					' V
					' ------------------------------------------

					Local baseV:Int

					baseV = GetBookValue(bookV,codeV,p)

					Local vValue:Int

					vValue = baseV + residualV[uGroup]

					vValue = vValue * 2

					vValue = ClampByte(vValue)

					' ------------------------------------------
					' ALPHA
					' ------------------------------------------

					Local alphaValue:Int

					alphaValue = blockA[p]

					' ------------------------------------------
					' COORDENADAS
					' ------------------------------------------

					Local px:Int
					Local py:Int

					px = bx * 8 + xx
					py = by * 8 + yy

					If px < width And py < height Then

						Local r:Int
						Local g:Int
						Local b:Int

						r = YUVToR(yValue,uValue,vValue)
						g = YUVToG(yValue,uValue,vValue)
						b = YUVToB(yValue,uValue,vValue)

						WritePixel(pix,px,py,MakePixel(r,g,b,alphaValue))

					EndIf

				Next

			Next

		Next

	Next

	Return pix

End Function


' ============================================================
' OUTPUT NAME
' ============================================================

Function MakeOutputName:String(outputFolder:String,relativePath:String)

	Local clean:String

	clean = relativePath.Replace("\","/")

	Local result:String

	result = JoinPath(outputFolder,clean)

	Local slash:Int

	slash = result.FindLast("/")

	If slash >= 0 Then

		Local outputDir:String

		outputDir = result[..slash]

		CreateDir(outputDir,True)

	EndIf

	Return result

End Function


' ============================================================
' SAVE IMAGE
' ============================================================

Function SaveDecodedImage:Int(pix:TPixmap,filename:String)

	Local lowerName:String

	lowerName = filename.ToLower()

	' ========================================================
	' PNG
	' ========================================================

	If lowerName.EndsWith(".png") Then

		Print "Guardar PNG: " + filename

		If SavePixmapPNG(pix,filename) Then

			Return True

		EndIf

		Print "ERRO a guardar PNG."

		Return False

	EndIf

	' ========================================================
	' JPG
	' ========================================================

	If lowerName.EndsWith(".jpg") Or lowerName.EndsWith(".jpeg") Then

		Print "Guardar JPEG: " + filename

		Local rgb:TPixmap

		rgb = ConvertPixmap(pix,PF_RGB888)

		If rgb = Null Then

			Print "ERRO: conversao RGB falhou."

			Return False

		EndIf

		If SavePixmapJPEG(rgb,filename) Then

			Return True

		EndIf

		Print "ERRO a guardar JPEG."

		Return False

	EndIf

	Print "Formato nao suportado: " + filename

	Return False

End Function


' ============================================================
' READ IMAGE HEADER
'
' IMPORTANTE:
'
' Le sempre os primeiros 4 bytes.
'
' Se forem SAFE:
'
'     termina a secao das imagens.
'
' Caso contrario:
'
'     esses mesmos 4 bytes sao o pathLength.
'
'
' Nao existe SeekStream.
' ============================================================

Function ReadImageHeader:Int(reader:TReader,relativePath:String Var,width:Int Var,height:Int Var,blocksX:Int Var,blocksY:Int Var,blockCount:Int Var)

	Local marker:String

	marker = ReadFourCC(reader)

	If reader.ok = False Then

		Return 0

	EndIf

	' ========================================================
	' SAFE
	' ========================================================

	If marker = "SAFE" Then

		Return 0

	EndIf

	' ========================================================
	' PATH LENGTH
	' ========================================================

	Local pathLength:Long

	pathLength = FourCCToU32(marker)

	If pathLength <= 0 Or pathLength > 1000000 Then

		Print "ERRO: tamanho de path invalido = " + pathLength

		Return 0

	EndIf

	relativePath = ReadASCII(reader,Int(pathLength))

	If reader.ok = False Then

		Print "ERRO: path incompleto."

		Return 0

	EndIf

	width = Int(ReadU32LE(reader))
	height = Int(ReadU32LE(reader))
	blocksX = Int(ReadU32LE(reader))
	blocksY = Int(ReadU32LE(reader))
	blockCount = Int(ReadU32LE(reader))

	If reader.ok = False Then

		Print "ERRO: header da imagem incompleto."

		Return 0

	EndIf

	Return 1

End Function


' ============================================================
' DECODE DATASET
' ============================================================

Function DecodeDataset(folder:String)

	Local filename:String

	filename = JoinPath(folder,"dataset.dat")

	Print ""
	Print "=========================================="
	Print "DECODER V12"
	Print "=========================================="

	Local stream:TStream

	stream = ReadStream(filename)

	If stream = Null Then

		Print "ERRO: nao abriu dataset.dat."

		Return

	EndIf

	Local reader:TReader

	reader = CreateReader(stream)

	' ========================================================
	' MAIN HEADER
	' ========================================================

	Local magic:String

	magic = ReadASCII(reader,4)

	If magic <> "DSET" Then

		Print "ERRO: DSET invalido."

		CloseStream(stream)

		Return

	EndIf

	Local version:Long

	version = ReadU32LE(reader)

	If version <> HEADERVERSION Then

		Print "ERRO: versao diferente."

		Print "Esperado = " + HEADERVERSION
		Print "Recebido = " + version

		CloseStream(stream)

		Return

	EndIf

	Local blockSize:Long

	blockSize = ReadU32LE(reader)

	If blockSize <> BLOCKSIZE Then

		Print "ERRO: BLOCKSIZE invalido."

		CloseStream(stream)

		Return

	EndIf

	Local blockBytes:Long

	blockBytes = ReadU32LE(reader)

	Print "BLOCK DATA = " + blockBytes

	If blockBytes <> 144 Then

		Print "AVISO: BLOCK DATA diferente de 144."

	EndIf

	Local sizeY:Int
	Local sizeU:Int
	Local sizeV:Int
	Local sizeA:Int

	sizeY = Int(ReadU32LE(reader))
	sizeU = Int(ReadU32LE(reader))
	sizeV = Int(ReadU32LE(reader))
	sizeA = Int(ReadU32LE(reader))

	Local quality:Int

	quality = Int(ReadU32LE(reader))

	Local imageCount:Long

	imageCount = ReadU32LE(reader)

	If reader.ok = False Then

		Print "ERRO: header incompleto."

		CloseStream(stream)

		Return

	EndIf

	Print ""
	Print "VERSION = " + version
	Print "BLOCK = " + blockSize
	Print "CODEBOOK Y = " + sizeY
	Print "CODEBOOK U = " + sizeU
	Print "CODEBOOK V = " + sizeV
	Print "CODEBOOK A = " + sizeA
	Print "QUALITY = " + quality
	Print "IMAGE COUNT = " + imageCount

	' ========================================================
	' IMGS
	' ========================================================

	Local imgsMarker:String

	imgsMarker = ReadASCII(reader,4)

	If imgsMarker <> "IMGS" Then

		Print "ERRO: marcador IMGS nao encontrado."

		CloseStream(stream)

		Return

	EndIf

	CloseStream(stream)

	' ========================================================
	' LOAD CODEBOOKS
	' ========================================================

	Print ""
	Print "=========================================="
	Print "CARREGAR CODEBOOKS"
	Print "=========================================="

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	bookY = LoadSafeTensor(JoinPath(folder,"datasetY.safetensors"),sizeY)

	If bookY = Null Then Return

	bookU = LoadSafeTensor(JoinPath(folder,"datasetU.safetensors"),sizeU)

	If bookU = Null Then Return

	bookV = LoadSafeTensor(JoinPath(folder,"datasetV.safetensors"),sizeV)

	If bookV = Null Then Return

	bookA = LoadSafeTensor(JoinPath(folder,"datasetA.safetensors"),sizeA)

	If bookA = Null Then Return

	' ========================================================
	' ABRIR DATASET NOVAMENTE
	'
	' Isto NAO e SeekStream.
	'
	' E uma nova leitura sequencial desde o inicio.
	' ========================================================

	stream = ReadStream(filename)

	If stream = Null Then

		Print "ERRO: nao abriu novamente dataset.dat."

		Return

	EndIf

	reader = CreateReader(stream)

	' ========================================================
	' SKIP MAIN HEADER
	' ========================================================

	ReadASCII(reader,4)
	ReadU32LE(reader)
	ReadU32LE(reader)
	ReadU32LE(reader)

	ReadU32LE(reader)
	ReadU32LE(reader)
	ReadU32LE(reader)
	ReadU32LE(reader)

	ReadU32LE(reader)
	ReadU32LE(reader)

	ReadASCII(reader,4)

	If reader.ok = False Then

		Print "ERRO a passar o header."

		CloseStream(stream)

		Return

	EndIf

	' ========================================================
	' IMAGES
	' ========================================================

	Local imageNumber:Int

	imageNumber = 0

	Local outputFolder:String

	outputFolder = JoinPath(folder,"decoded")

	CreateDir(outputFolder,True)

	While reader.ok

		Local relativePath:String

		Local width:Int
		Local height:Int
		Local blocksX:Int
		Local blocksY:Int
		Local blockCount:Int

		' ====================================================
		' LER HEADER
		'
		' Aqui o SAFE e reconhecido diretamente.
		' Nenhum byte e devolvido ao stream.
		' ====================================================

		If ReadImageHeader(reader,relativePath,width,height,blocksX,blocksY,blockCount) = 0 Then

			Exit

		EndIf

		Print ""
		Print "------------------------------------------"
		Print "IMAGEM " + (imageNumber + 1)
		Print relativePath
		Print "TAMANHO = " + width + " x " + height
		Print "BLOCOS = " + blocksX + " x " + blocksY
		Print "TOTAL = " + blockCount

		Local expectedBlocks:Int

		expectedBlocks = blocksX * blocksY

		If blockCount <> expectedBlocks Then

			Print "ERRO: blockCount invalido."

			CloseStream(stream)

			Return

		EndIf

		' ====================================================
		' DECODE
		' ====================================================

		Local pix:TPixmap

		pix = DecodeImage(reader,width,height,blocksX,blocksY,bookY,bookU,bookV,bookA,quality)

		If pix = Null Then

			Print "ERRO a descodificar " + relativePath

			CloseStream(stream)

			Return

		EndIf

		' ====================================================
		' SAVE
		' ====================================================

		Local outputName:String

		outputName = MakeOutputName(outputFolder,relativePath)

		If SaveDecodedImage(pix,outputName) Then

			Print "OK: " + outputName

		Else

			Print "ERRO: " + outputName

		EndIf

		imageNumber :+ 1

	Wend

	CloseStream(stream)

	Print ""
	Print "=========================================="
	Print "DECODIFICACAO TERMINADA"
	Print "=========================================="

	Print "IMAGENS = " + imageNumber

End Function


' ============================================================
' MAIN
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DATASET DECODER V12"
	Print "=========================================="

	Print ""

	Local folder:String

	folder = Input("Folder do dataset: ")

	If folder = "" Then

		Print "Folder vazio."

		Return

	EndIf

	DecodeDataset(folder)

	Print ""
	Print "ESC para sair."

End Function


' ============================================================
' RUN
' ============================================================

Main()

Repeat

	Delay(20)

Until KeyHit(KEY_ESCAPE)

EndGraphics