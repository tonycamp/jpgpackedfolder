SuperStrict

Import BRL.StandardIO
Import BRL.Pixmap
Import BRL.JPGLoader
Import BRL.PNGLoader
Import BRL.Random

Graphics 1920,1080


' ============================================================
' DATASET CODEBOOK ENCODER V12
'
' FM 2026 / DATASETS GRANDES
'
' V12:
'
'   - STREAMING DE FICHEIROS
'   - NAO GUARDA 1.5M PATHS EM MEMORIA
'   - TREINO POR AMOSTRAGEM
'   - SEGUNDA PASSAGEM PARA CODIFICACAO
'   - 8x8
'   - QUALQUER LARGURA
'   - QUALQUER ALTURA
'   - PADDING POR REPLICACAO DA BORDA
'
' COLOR:
'
'   RGB -> YUV -> /2
'   SEM HAAR
'   SEM ZIGZAG
'
' ALPHA:
'
'   RAW 8-BIT LOSSLESS
'
' BLOCO:
'
'   codeY = 2 bytes
'   codeU = 2 bytes
'   codeV = 2 bytes
'   codeA = 2 bytes
'
'   Y = 64 bytes
'   U = 4 bytes
'   V = 4 bytes
'   A = 64 bytes RAW
'
'   TOTAL = 144 BYTES
'
'
' DATASET.DAT V12:
'
'   DSET
'   VERSION
'   BLOCKSIZE
'   BLOCK_DATA_BYTES
'   CODEBOOK SIZES
'   QUALITY
'   IMAGE COUNT
'   IMAGE HEADERS
'   IMAGE DATA
'   SAFE
'   SATY
'   SATU
'   SATV
'   SATA
'   DONE
'
' ============================================================


Const BLOCKSIZE:Int = 8
Const BLOCKPIXELS:Int = 64

Const BLOCK_DATA_BYTES:Int = 144

Const CODEBOOKSIZEY:Int = 4096
Const CODEBOOKSIZEC:Int = 1024
Const CODEBOOKSIZEA:Int = 256

Const HASHCAPACITY:Int = 131072
Const INDEXSIZE:Int = 256

Const TRAIN_ITERATIONS:Int = 5

Const HEADER_VERSION:Int = 12

' ============================================================
' TREINO V12
'
' Estes valores podem ser alterados.
'
' O dataset inteiro NAO e carregado para memoria.
'
' ============================================================

Const TRAIN_MAX_IMAGES:Int = 50000
Const TRAIN_MAX_BLOCKS:Long = 1000000

' Mostra progresso a cada N ficheiros.
Const PROGRESS_EVERY:Int = 1000

' ============================================================
' IMAGE INFO
' ============================================================

Type TImageInfo

	Field name:String
	Field path:String
	Field relativePath:String

	Field width:Int
	Field height:Int

	Field blocks:Int
	Field blocksX:Int
	Field blocksY:Int

End Type


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int

	Field data:Int[]

	Field bucketHead:Int[]
	Field bucketNext:Int[]

	Field hashKey:Int[]
	Field hashCode:Int[]
	Field hashUsed:Byte[]

	Field hashCapacity:Int

End Type


' ============================================================
' CREATE CODEBOOK
' ============================================================

Function CreateCodeBook:TCodeBook(codeCount:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = codeCount

	book.data = New Int[codeCount * BLOCKPIXELS]

	book.bucketHead = New Int[INDEXSIZE]
	book.bucketNext = New Int[codeCount]

	For Local i:Int = 0 Until INDEXSIZE
		book.bucketHead[i] = -1
	Next

	For Local i:Int = 0 Until codeCount
		book.bucketNext[i] = -1
	Next

	book.hashCapacity = HASHCAPACITY

	book.hashKey = New Int[book.hashCapacity]
	book.hashCode = New Int[book.hashCapacity]
	book.hashUsed = New Byte[book.hashCapacity]

	Return book

End Function


' ============================================================
' CLAMP BYTE
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then Return 0
	If value > 255 Then Return 255

	Return value

End Function


' ============================================================
' CLAMP COORDINATE
' ============================================================

Function ClampCoord:Int(value:Int,maxValue:Int)

	If maxValue <= 0 Then Return 0

	If value < 0 Then Return 0

	If value >= maxValue Then Return maxValue - 1

	Return value

End Function


' ============================================================
' JOIN PATH
' ============================================================

Function JoinPath:String(folder:String,name:String)

	If folder.EndsWith("/") Then
		Return folder + name
	EndIf

	If folder.EndsWith("\") Then
		Return folder + name
	EndIf

	Return folder + "/" + name

End Function


' ============================================================
' NORMALIZE PATH
' ============================================================

Function NormalizeRelativePath:String(path:String)

	Local result:String

	result = path.Replace("\","/")

	While result.StartsWith("./")
		result = result[2..]
	Wend

	Return result

End Function


' ============================================================
' FILE NAME
' ============================================================

Function GetFileNameFromPath:String(path:String)

	Local p:String

	p = NormalizeRelativePath(path)

	Local slash:Int

	slash = p.FindLast("/")

	If slash >= 0 Then
		Return p[slash + 1..]
	EndIf

	Return p

End Function


' ============================================================
' IMAGE FILE
' ============================================================

Function IsImageFile:Int(name:String)

	Local n:String

	n = name.ToLower()

	If n.EndsWith(".png") Then Return True
	If n.EndsWith(".jpg") Then Return True
	If n.EndsWith(".jpeg") Then Return True
	If n.EndsWith(".bmp") Then Return True
	If n.EndsWith(".tga") Then Return True

	Return False

End Function


' ============================================================
' ADD STRING
' ============================================================

Function AddStringToArray:String[](array:String[],value:String)

	Local oldLength:Int

	oldLength = array.Length

	array = array[..oldLength + 1]

	array[oldLength] = value

	Return array

End Function


' ============================================================
' RGB -> Y
' ============================================================

Function RGBToY:Int(r:Int,g:Int,b:Int)

	Local y:Int

	y = Int(0.257 * Float(r) + 0.504 * Float(g) + 0.098 * Float(b) + 16.0)

	Return ClampByte(y)

End Function


' ============================================================
' RGB -> U
' ============================================================

Function RGBToU:Int(r:Int,g:Int,b:Int)

	Local u:Int

	u = Int(-0.148 * Float(r) - 0.291 * Float(g) + 0.439 * Float(b) + 128.0)

	Return ClampByte(u)

End Function


' ============================================================
' RGB -> V
' ============================================================

Function RGBToV:Int(r:Int,g:Int,b:Int)

	Local v:Int

	v = Int(0.439 * Float(r) - 0.368 * Float(g) - 0.071 * Float(b) + 128.0)

	Return ClampByte(v)

End Function


' ============================================================
' YUV -> RGB
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)
	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' GET CHANNEL
' ============================================================

Function GetPixelChannel:Int(pix:TPixmap,x:Int,y:Int,channel:Int)

	x = ClampCoord(x,pix.width)
	y = ClampCoord(y,pix.height)

	Local pixel:Int

	pixel = ReadPixel(pix,x,y)

	Local r:Int
	Local g:Int
	Local b:Int

	r = (pixel Shr 16) & $FF
	g = (pixel Shr 8) & $FF
	b = pixel & $FF

	Local value:Int

	If channel = 0 Then

		value = RGBToY(r,g,b)

	ElseIf channel = 1 Then

		value = RGBToU(r,g,b)

	Else

		value = RGBToV(r,g,b)

	EndIf

	Return value / 2

End Function


' ============================================================
' GET ALPHA
' ============================================================

Function GetPixelAlpha:Int(pix:TPixmap,x:Int,y:Int)

	x = ClampCoord(x,pix.width)
	y = ClampCoord(y,pix.height)

	Local pixel:Int

	pixel = ReadPixel(pix,x,y)

	Select pix.format

		Case PF_RGBA8888
			Return (pixel Shr 24) & $FF

		Case PF_BGRA8888
			Return (pixel Shr 24) & $FF

		Case PF_ARGB8888
			Return (pixel Shr 24) & $FF

		Default
			Return 255

	End Select

End Function


' ============================================================
' HASH BOOK
' ============================================================

Function HashBookBlock:Int(book:TCodeBook,code:Int)

	Local h:Long
	Local base:Int

	h = 2166136261
	base = code * BLOCKPIXELS

	For Local i:Int = 0 Until BLOCKPIXELS

		h = h + Long(book.data[base + i] + 1) * Long(i + 1) * 16777619

		h = h * 16777619
		h = h & $FFFFFFFF

	Next

	Return Int(h)

End Function


' ============================================================
' HASH BLOCK
' ============================================================

Function HashBlock:Int(block:Int[])

	Local h:Long

	h = 2166136261

	For Local i:Int = 0 Until BLOCKPIXELS

		h = h + Long(block[i] + 1) * Long(i + 1) * 16777619

		h = h * 16777619
		h = h & $FFFFFFFF

	Next

	Return Int(h)

End Function


' ============================================================
' HASH SLOT
' ============================================================

Function HashSlot:Int(hash:Int,capacity:Int)

	If capacity <= 0 Then Return 0

	Return hash & (capacity - 1)

End Function


' ============================================================
' CLEAR HASH
' ============================================================

Function ClearHashTable(book:TCodeBook)

	For Local i:Int = 0 Until book.hashCapacity

		book.hashUsed[i] = 0
		book.hashKey[i] = 0
		book.hashCode[i] = -1

	Next

End Function


' ============================================================
' HASH INSERT
' ============================================================

Function HashInsert(book:TCodeBook,hash:Int,code:Int)

	Local slot:Int

	slot = HashSlot(hash,book.hashCapacity)

	For Local attempt:Int = 0 Until book.hashCapacity

		If book.hashUsed[slot] = 0 Then

			book.hashUsed[slot] = 1
			book.hashKey[slot] = hash
			book.hashCode[slot] = code

			Return

		EndIf

		If book.hashKey[slot] = hash Then Return

		slot :+ 1

		If slot >= book.hashCapacity Then
			slot = 0
		EndIf

	Next

End Function


' ============================================================
' HASH FIND
' ============================================================

Function HashFind:Int(book:TCodeBook,hash:Int)

	Local slot:Int

	slot = HashSlot(hash,book.hashCapacity)

	For Local attempt:Int = 0 Until book.hashCapacity

		If book.hashUsed[slot] = 0 Then Return -1

		If book.hashKey[slot] = hash Then
			Return book.hashCode[slot]
		EndIf

		slot :+ 1

		If slot >= book.hashCapacity Then
			slot = 0
		EndIf

	Next

	Return -1

End Function


' ============================================================
' BLOCK AVERAGE
' ============================================================

Function CalculateBlockAverage:Int(book:TCodeBook,code:Int)

	Local base:Int
	Local total:Int

	base = code * BLOCKPIXELS
	total = 0

	For Local p:Int = 0 Until BLOCKPIXELS
		total :+ book.data[base + p]
	Next

	Return total / BLOCKPIXELS

End Function


' ============================================================
' INDEX
' ============================================================

Function MakeIndex:Int(avg:Int)

	If avg < 0 Then avg = 0
	If avg > 255 Then avg = 255

	Return avg

End Function


' ============================================================
' BUILD INDEX
' ============================================================

Function BuildCodeBookIndex(book:TCodeBook)

	ClearHashTable(book)

	For Local i:Int = 0 Until INDEXSIZE
		book.bucketHead[i] = -1
	Next

	For Local i:Int = 0 Until book.size
		book.bucketNext[i] = -1
	Next

	For Local code:Int = 0 Until book.size

		Local avg:Int

		avg = CalculateBlockAverage(book,code)

		Local bucket:Int

		bucket = MakeIndex(avg)

		book.bucketNext[code] = book.bucketHead[bucket]
		book.bucketHead[bucket] = code

		Local hash:Int

		hash = HashBookBlock(book,code)

		If HashFind(book,hash) = -1 Then
			HashInsert(book,hash,code)
		EndIf

	Next

End Function


' ============================================================
' BLOCK DISTANCE
' ============================================================

Function BlockDistance:Int(book:TCodeBook,code:Int,block:Int[])

	Local base:Int
	Local distance:Long

	base = code * BLOCKPIXELS
	distance = 0

	For Local p:Int = 0 Until BLOCKPIXELS

		Local d:Int

		d = book.data[base + p] - block[p]

		distance :+ Long(d) * Long(d)

		If distance > 2147483647 Then
			Return 2147483647
		EndIf

	Next

	Return Int(distance)

End Function


' ============================================================
' FIND NEAREST
' ============================================================

Function FindNearest:Int(book:TCodeBook,block:Int[])

	Local hash:Int

	hash = HashBlock(block)

	Local exactCode:Int

	exactCode = HashFind(book,hash)

	If exactCode >= 0 Then

		Local base:Int

		base = exactCode * BLOCKPIXELS

		Local exact:Int

		exact = True

		For Local p:Int = 0 Until BLOCKPIXELS

			If book.data[base + p] <> block[p] Then

				exact = False
				Exit

			EndIf

		Next

		If exact Then Return exactCode

	EndIf

	Local total:Int

	total = 0

	For Local p:Int = 0 Until BLOCKPIXELS
		total :+ block[p]
	Next

	Local average:Int

	average = total / BLOCKPIXELS

	Local bestCode:Int
	Local bestDistance:Int

	bestCode = 0
	bestDistance = 2147483647

	For Local delta:Int = -16 To 16

		Local bucket:Int

		bucket = average + delta

		If bucket < 0 Then Continue
		If bucket >= INDEXSIZE Then Continue

		Local code:Int

		code = book.bucketHead[bucket]

		While code >= 0

			Local distance:Int

			distance = BlockDistance(book,code,block)

			If distance < bestDistance Then

				bestDistance = distance
				bestCode = code

			EndIf

			code = book.bucketNext[code]

		Wend

	Next

	Return bestCode

End Function


' ============================================================
' COPY BLOCK
' ============================================================

Function CopyBlockToBook(book:TCodeBook,code:Int,pix:TPixmap,bx:Int,by:Int,channel:Int)

	Local base:Int

	base = code * BLOCKPIXELS

	For Local yy:Int = 0 Until 8

		For Local xx:Int = 0 Until 8

			Local px:Int
			Local py:Int
			Local p:Int

			px = bx * 8 + xx
			py = by * 8 + yy

			p = yy * 8 + xx

			If channel = 3 Then

				book.data[base + p] = GetPixelAlpha(pix,px,py)

			Else

				book.data[base + p] = GetPixelChannel(pix,px,py,channel)

			EndIf

		Next

	Next

End Function


' ============================================================
' COPY CODE
' ============================================================

Function CopyCode(book:TCodeBook,destination:Int,source:Int)

	Local dstBase:Int
	Local srcBase:Int

	dstBase = destination * BLOCKPIXELS
	srcBase = source * BLOCKPIXELS

	For Local p:Int = 0 Until BLOCKPIXELS
		book.data[dstBase + p] = book.data[srcBase + p]
	Next

End Function


' ============================================================
' COLLECT IMAGE FILES
'
' V12:
'
' Esta funcao e usada apenas para recolher uma amostra
' de treino.
'
' NAO e usada para guardar o dataset inteiro.
'
' ============================================================

Function CollectTrainingFiles:String[](folder:String,maxImages:Int)

	Local result:String[]

	result = New String[0]

	RecursiveCollectTraining(folder,"",result,maxImages)

	Return result

End Function


' ============================================================
' RECURSIVE TRAINING COLLECT
' ============================================================

Function RecursiveCollectTraining(folder:String,relativeFolder:String,result:String[] Var,maxImages:Int)

	If result.Length >= maxImages Then Return

	Local currentFolder:String

	If relativeFolder = "" Then
		currentFolder = folder
	Else
		currentFolder = JoinPath(folder,relativeFolder)
	EndIf

	Local all:String[]

	all = LoadDir(currentFolder)

	If all = Null Then Return

	For Local name:String = EachIn all

		If result.Length >= maxImages Then Return

		If name = "." Then Continue
		If name = ".." Then Continue

		Local relativeName:String

		If relativeFolder = "" Then
			relativeName = name
		Else
			relativeName = relativeFolder + "/" + name
		EndIf

		relativeName = NormalizeRelativePath(relativeName)

		Local fullPath:String

		fullPath = JoinPath(folder,relativeName)

		If IsImageFile(name) Then

			result = AddStringToArray(result,relativeName)

			If result.Length Mod 1000 = 0 Then
				Print "Amostra de treino: " + result.Length + " / " + maxImages
			EndIf

		Else

			Local child:String[]

			child = LoadDir(fullPath)

			If child <> Null Then

				RecursiveCollectTraining(folder,relativeName,result,maxImages)

			EndIf

		EndIf

	Next

End Function


' ============================================================
' TRAIN CODEBOOK
' ============================================================

Function TrainCodeBook:TCodeBook(files:String[],folder:String,channel:Int,codeCount:Int)

	Local book:TCodeBook

	book = CreateCodeBook(codeCount)

	Print ""
	Print "=========================================="

	If channel = 0 Then
		Print "TREINO Y"
	ElseIf channel = 1 Then
		Print "TREINO U"
	ElseIf channel = 2 Then
		Print "TREINO V"
	Else
		Print "TREINO ALPHA"
	EndIf

	Print "IMAGENS DE TREINO = " + files.Length
	Print "CODEBOOK = " + codeCount
	Print "ITERACOES = " + TRAIN_ITERATIONS

	Print "=========================================="

	If files.Length = 0 Then Return book

	' ========================================================
	' INITIALIZATION
	' ========================================================

	Local nextCode:Int

	nextCode = 0

	For Local f:Int = 0 Until files.Length

		If nextCode >= codeCount Then Exit

		Local path:String

		path = JoinPath(folder,files[f])

		Local pix:TPixmap

		pix = LoadPixmap(path)

		If pix = Null Then Continue

		Local blocksX:Int
		Local blocksY:Int

		blocksX = (pix.width + 7) / 8
		blocksY = (pix.height + 7) / 8

		For Local by:Int = 0 Until blocksY

			For Local bx:Int = 0 Until blocksX

				If nextCode >= codeCount Then Exit

				CopyBlockToBook(book,nextCode,pix,bx,by,channel)

				nextCode :+ 1

			Next

			If nextCode >= codeCount Then Exit

		Next

		If f Mod PROGRESS_EVERY = 0 Then

			Print "Inicializacao codebook: " + f + " / " + files.Length

		EndIf

	Next

	If nextCode <= 0 Then

		Print "ERRO: nenhum bloco para treino."

		Return book

	EndIf

	Local trainedCodes:Int

	trainedCodes = nextCode

	While nextCode < codeCount

		CopyCode(book,nextCode,nextCode Mod trainedCodes)

		nextCode :+ 1

	Wend

	BuildCodeBookIndex(book)

	' ========================================================
	' K-MEANS
	' ========================================================

	Local sums:Long[]
	Local counts:Long[]

	sums = New Long[codeCount * BLOCKPIXELS]
	counts = New Long[codeCount]

	Local block:Int[]

	block = New Int[BLOCKPIXELS]

	For Local iteration:Int = 1 To TRAIN_ITERATIONS

		Print ""
		Print "Treino iteracao " + iteration + " / " + TRAIN_ITERATIONS

		For Local i:Int = 0 Until sums.Length
			sums[i] = 0
		Next

		For Local i:Int = 0 Until counts.Length
			counts[i] = 0
		Next

		For Local f:Int = 0 Until files.Length

			Local path:String

			path = JoinPath(folder,files[f])

			Local pix:TPixmap

			pix = LoadPixmap(path)

			If pix = Null Then Continue

			Local blocksX:Int
			Local blocksY:Int

			blocksX = (pix.width + 7) / 8
			blocksY = (pix.height + 7) / 8

			For Local by:Int = 0 Until blocksY

				For Local bx:Int = 0 Until blocksX

					For Local yy:Int = 0 Until 8

						For Local xx:Int = 0 Until 8

							Local px:Int
							Local py:Int
							Local p:Int

							px = bx * 8 + xx
							py = by * 8 + yy

							p = yy * 8 + xx

							If channel = 3 Then

								block[p] = GetPixelAlpha(pix,px,py)

							Else

								block[p] = GetPixelChannel(pix,px,py,channel)

							EndIf

						Next

					Next

					Local bestCode:Int

					bestCode = FindNearest(book,block)

					Local base:Int

					base = bestCode * BLOCKPIXELS

					For Local p:Int = 0 Until BLOCKPIXELS

						sums[base + p] :+ Long(block[p])

					Next

					counts[bestCode] :+ 1

				Next

			Next

			If f Mod PROGRESS_EVERY = 0 Then

				Print "  " + f + " / " + files.Length

			EndIf

		Next

		' ====================================================
		' UPDATE
		' ====================================================

		Local changed:Int

		changed = 0

		For Local code:Int = 0 Until codeCount

			If counts[code] <= 0 Then Continue

			Local base:Int

			base = code * BLOCKPIXELS

			For Local p:Int = 0 Until BLOCKPIXELS

				Local oldValue:Int
				Local newValue:Int

				oldValue = book.data[base + p]

				newValue = Int(sums[base + p] / counts[code])

				If channel < 3 Then

					If newValue < 0 Then newValue = 0
					If newValue > 127 Then newValue = 127

				Else

					If newValue < 0 Then newValue = 0
					If newValue > 255 Then newValue = 255

				EndIf

				If oldValue <> newValue Then
					changed :+ 1
				EndIf

				book.data[base + p] = newValue

			Next

		Next

		Print "Valores alterados = " + changed

		BuildCodeBookIndex(book)

	Next

	Print "Treino terminado."

	Return book

End Function


' ============================================================
' QUANTIZE
' ============================================================

Function QuantizeResidual8:Int(value:Float,quantLevel:Int)

	If quantLevel <= 1 Then

		Local q:Int

		q = Int(value)

		If q < -128 Then q = -128
		If q > 127 Then q = 127

		Return q

	EndIf

	Local q:Int

	If value >= 0.0 Then

		q = Int((value + Float(quantLevel) * 0.5) / Float(quantLevel))

	Else

		q = -Int(((-value) + Float(quantLevel) * 0.5) / Float(quantLevel))

	EndIf

	If q < -128 Then q = -128
	If q > 127 Then q = 127

	Return q

End Function


' ============================================================
' WRITE U16
' ============================================================

Function WriteU16LE(stream:TStream,value:Int)

	WriteByte(stream,value & $FF)
	WriteByte(stream,(value Shr 8) & $FF)

End Function


' ============================================================
' WRITE U32
' ============================================================

Function WriteU32LE(stream:TStream,value:Int)

	WriteByte(stream,value & $FF)
	WriteByte(stream,(value Shr 8) & $FF)
	WriteByte(stream,(value Shr 16) & $FF)
	WriteByte(stream,(value Shr 24) & $FF)

End Function


' ============================================================
' WRITE U64
' ============================================================

Function WriteU64LE(stream:TStream,value:Long)

	For Local i:Int = 0 Until 8

		WriteByte(stream,Int(value & $FF))

		value = value Shr 8

	Next

End Function


' ============================================================
' WRITE ASCII
' ============================================================

Function WriteASCII(stream:TStream,text:String)

	For Local i:Int = 0 Until text.Length

		WriteByte(stream,text[i] & $FF)

	Next

End Function


' ============================================================
' SAVE SAFETENSOR
' ============================================================

Function SaveSafeTensor(book:TCodeBook,filename:String,tagName:String)

	Print "A gravar " + filename

	Local dataSize:Int

	dataSize = book.size * BLOCKPIXELS

	Local quote:String

	quote = Chr(34)

	Local header:String

	header = "{" + quote + tagName + quote + ":{" + quote + "dtype" + quote + ":" + quote + "U8" + quote + "," + quote + "shape" + quote + ":[" + book.size + "," + BLOCKPIXELS + "]," + quote + "data_offsets" + quote + ":[0," + dataSize + "]}}"

	Local stream:TStream

	stream = WriteStream(filename)

	If stream = Null Then

		Print "ERRO: " + filename

		Return

	EndIf

	WriteU64LE(stream,Long(header.Length))

	WriteASCII(stream,header)

	For Local i:Int = 0 Until book.data.Length

		WriteByte(stream,book.data[i] & $FF)

	Next

	CloseStream(stream)

	Print "OK " + filename

End Function


' ============================================================
' IMAGE HEADER
' ============================================================

Function WriteImageHeader(stream:TStream,relativePath:String,pix:TPixmap)

	Local path:String

	path = NormalizeRelativePath(relativePath)

	Local blocksX:Int
	Local blocksY:Int

	blocksX = (pix.width + 7) / 8
	blocksY = (pix.height + 7) / 8

	WriteU32LE(stream,path.Length)

	WriteASCII(stream,path)

	WriteU32LE(stream,pix.width)
	WriteU32LE(stream,pix.height)
	WriteU32LE(stream,blocksX)
	WriteU32LE(stream,blocksY)
	WriteU32LE(stream,blocksX * blocksY)

End Function


' ============================================================
' C RESIDUAL
' ============================================================

Function CalculateCResiduals:Int[](block:Int[],book:TCodeBook,code:Int)

	Local residuals:Int[]

	residuals = New Int[4]

	Local base:Int

	base = code * 64

	For Local gy:Int = 0 Until 2

		For Local gx:Int = 0 Until 2

			Local total:Int

			total = 0

			For Local yy:Int = 0 Until 4

				For Local xx:Int = 0 Until 4

					Local x:Int
					Local y:Int
					Local p:Int

					x = gx * 4 + xx
					y = gy * 4 + yy

					p = y * 8 + x

					total :+ block[p] - book.data[base + p]

				Next

			Next

			residuals[gy * 2 + gx] = total / 16

		Next

	Next

	Return residuals

End Function


' ============================================================
' ENCODE IMAGE
' ============================================================

Function EncodeImage(stream:TStream,relativePath:String,pix:TPixmap,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	Local quantY:Int
	Local quantC:Int

	quantY = 64 - (qualityLevel * 63 / 100)
	quantC = 96 - (qualityLevel * 95 / 100)

	If quantY < 1 Then quantY = 1
	If quantC < 1 Then quantC = 1

	Local blockY:Int[]
	Local blockU:Int[]
	Local blockV:Int[]
	Local blockA:Int[]

	blockY = New Int[64]
	blockU = New Int[64]
	blockV = New Int[64]
	blockA = New Int[64]

	Local blocksX:Int
	Local blocksY:Int

	blocksX = (pix.width + 7) / 8
	blocksY = (pix.height + 7) / 8

	For Local by:Int = 0 Until blocksY

		For Local bx:Int = 0 Until blocksX

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local px:Int
					Local py:Int
					Local p:Int

					px = bx * 8 + xx
					py = by * 8 + yy

					p = yy * 8 + xx

					blockY[p] = GetPixelChannel(pix,px,py,0)
					blockU[p] = GetPixelChannel(pix,px,py,1)
					blockV[p] = GetPixelChannel(pix,px,py,2)
					blockA[p] = GetPixelAlpha(pix,px,py)

				Next

			Next

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int
			Local codeA:Int

			codeY = FindNearest(bookY,blockY)
			codeU = FindNearest(bookU,blockU)
			codeV = FindNearest(bookV,blockV)
			codeA = FindNearest(bookA,blockA)

			' ================================================
			' Y
			' ================================================

			Local residualY:Int[]

			residualY = New Int[64]

			Local baseY:Int

			baseY = codeY * 64

			For Local p:Int = 0 Until 64

				Local raw:Int

				raw = blockY[p] - bookY.data[baseY + p]

				residualY[p] = QuantizeResidual8(Float(raw),quantY)

			Next

			' ================================================
			' U / V
			' ================================================

			Local rawU:Int[]
			Local rawV:Int[]

			rawU = CalculateCResiduals(blockU,bookU,codeU)
			rawV = CalculateCResiduals(blockV,bookV,codeV)

			Local residualU:Int[]
			Local residualV:Int[]

			residualU = New Int[4]
			residualV = New Int[4]

			For Local i:Int = 0 Until 4

				residualU[i] = QuantizeResidual8(Float(rawU[i]),quantC)
				residualV[i] = QuantizeResidual8(Float(rawV[i]),quantC)

			Next

			' ================================================
			' HEADER
			' ================================================

			WriteU16LE(stream,codeY)
			WriteU16LE(stream,codeU)
			WriteU16LE(stream,codeV)
			WriteU16LE(stream,codeA)

			' ================================================
			' Y
			' ================================================

			For Local i:Int = 0 Until 64

				WriteByte(stream,(residualY[i] + 128) & $FF)

			Next

			' ================================================
			' U
			' ================================================

			For Local i:Int = 0 Until 4

				WriteByte(stream,(residualU[i] + 128) & $FF)

			Next

			' ================================================
			' V
			' ================================================

			For Local i:Int = 0 Until 4

				WriteByte(stream,(residualV[i] + 128) & $FF)

			Next

			' ================================================
			' ALPHA RAW
			' ================================================

			For Local i:Int = 0 Until 64

				WriteByte(stream,blockA[i] & $FF)

			Next

		Next

	Next

End Function


' ============================================================
' COPY FILE
' ============================================================

Function CopyFileIntoStream:Int(output:TStream,filename:String)

	Local inputStream:TStream

	inputStream = ReadStream(filename)

	If inputStream = Null Then Return 0

	Local bytesInFile:Long

	bytesInFile = StreamSize(inputStream)

	If bytesInFile < 0 Or bytesInFile > 2147483647 Then

		CloseStream(inputStream)

		Return 0

	EndIf

	If bytesInFile > 0 Then

		CopyBytes(inputStream,output,Int(bytesInFile))

	EndIf

	CloseStream(inputStream)

	Return 1

End Function


' ============================================================
' APPEND SAFETENSOR
' ============================================================

Function AppendSafeTensor:Int(output:TStream,filename:String,tag:String)

	If Not FileExists(filename) Then

		Print "ERRO: nao existe " + filename

		Return 0

	EndIf

	Local fileBytes:Long

	fileBytes = FileSize(filename)

	If fileBytes < 0 Then Return 0

	WriteASCII(output,tag)

	WriteU64LE(output,fileBytes)

	If CopyFileIntoStream(output,filename) = 0 Then

		Return 0

	EndIf

	Return 1

End Function


' ============================================================
' SCAN DATASET
'
' Segunda passagem.
'
' Nao guarda paths.
'
' ============================================================

Function EncodeDatasetStreaming:Int(folder:String,stream:TStream,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	Local imageCount:Int

	imageCount = 0

	Local encodedBlocks:Long

	encodedBlocks = 0

	Print ""
	Print "=========================================="
	Print "SEGUNDA PASSAGEM"
	Print "CODIFICACAO STREAMING"
	Print "=========================================="

	RecursiveEncodeFolder(folder,"",stream,bookY,bookU,bookV,bookA,qualityLevel,imageCount,encodedBlocks)

	Print ""
	Print "IMAGENS CODIFICADAS = " + imageCount
	Print "BLOCOS CODIFICADOS  = " + encodedBlocks

	Return imageCount

End Function


' ============================================================
' RECURSIVE ENCODE
' ============================================================

Function RecursiveEncodeFolder(folder:String,relativeFolder:String,stream:TStream,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int,imageCount:Int Var,encodedBlocks:Long Var)

	Local currentFolder:String

	If relativeFolder = "" Then

		currentFolder = folder

	Else

		currentFolder = JoinPath(folder,relativeFolder)

	EndIf

	Local all:String[]

	all = LoadDir(currentFolder)

	If all = Null Then Return

	For Local name:String = EachIn all

		If name = "." Then Continue
		If name = ".." Then Continue

		Local relativeName:String

		If relativeFolder = "" Then

			relativeName = name

		Else

			relativeName = relativeFolder + "/" + name

		EndIf

		relativeName = NormalizeRelativePath(relativeName)

		Local fullPath:String

		fullPath = JoinPath(folder,relativeName)

		If IsImageFile(name) Then

			Local pix:TPixmap

			pix = LoadPixmap(fullPath)

			If pix = Null Then

				Print "AVISO: falhou " + relativeName

				Continue

			EndIf

			If pix.width <= 0 Or pix.height <= 0 Then

				Continue

			EndIf

			WriteImageHeader(stream,relativeName,pix)

			EncodeImage(stream,relativeName,pix,bookY,bookU,bookV,bookA,qualityLevel)

			Local blocksX:Int
			Local blocksY:Int

			blocksX = (pix.width + 7) / 8
			blocksY = (pix.height + 7) / 8

			encodedBlocks :+ Long(blocksX) * Long(blocksY)

			imageCount :+ 1

			If imageCount Mod PROGRESS_EVERY = 0 Then

				Print "Imagens = " + imageCount + "   Blocos = " + encodedBlocks

			EndIf

		Else

			Local child:String[]

			child = LoadDir(fullPath)

			If child <> Null Then

				RecursiveEncodeFolder(folder,relativeName,stream,bookY,bookU,bookV,bookA,qualityLevel,imageCount,encodedBlocks)

			EndIf

		EndIf

	Next

End Function


' ============================================================
' CREATE DATASET
' ============================================================

Function CreateDataset(folder:String,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	Local filename:String

	filename = JoinPath(folder,"dataset.dat")

	Print ""
	Print "=========================================="
	Print "CRIAR DATASET.DAT V12"
	Print "=========================================="

	Local stream:TStream

	stream = WriteStream(filename)

	If stream = Null Then

		Print "ERRO: nao consegui criar dataset.dat"

		Return

	EndIf

	' ========================================================
	' MAIN HEADER
	'
	' V12 usa IMAGE COUNT = 0xFFFFFFFF
	'
	' porque o encoder trabalha em streaming.
	'
	' O decoder sabe que os headers terminam quando
	' encontra IMAGE DATA.
	'
	' Para simplificar o decoder V12, os headers e dados
	' serao separados por MARK.
	' ========================================================

	WriteASCII(stream,"DSET")

	WriteU32LE(stream,HEADER_VERSION)

	WriteU32LE(stream,BLOCKSIZE)

	WriteU32LE(stream,BLOCK_DATA_BYTES)

	WriteU32LE(stream,bookY.size)
	WriteU32LE(stream,bookU.size)
	WriteU32LE(stream,bookV.size)
	WriteU32LE(stream,bookA.size)

	WriteU32LE(stream,qualityLevel)

	' IMAGE COUNT DESCONHECIDO
	WriteU32LE(stream,$FFFFFFFF)

	' ========================================================
	' IMAGE DATA MARKER
	' ========================================================

	WriteASCII(stream,"IMGS")

	' ========================================================
	' ENCODE STREAMING
	' ========================================================

	EncodeDatasetStreaming(folder,stream,bookY,bookU,bookV,bookA,qualityLevel)

	' ========================================================
	' SAFE
	' ========================================================

	WriteASCII(stream,"SAFE")

	Print ""
	Print "A embutir SafeTensors..."

	If AppendSafeTensor(stream,JoinPath(folder,"datasetY.safetensors"),"SATY") = 0 Then
		Print "ERRO SATY"
	EndIf

	If AppendSafeTensor(stream,JoinPath(folder,"datasetU.safetensors"),"SATU") = 0 Then
		Print "ERRO SATU"
	EndIf

	If AppendSafeTensor(stream,JoinPath(folder,"datasetV.safetensors"),"SATV") = 0 Then
		Print "ERRO SATV"
	EndIf

	If AppendSafeTensor(stream,JoinPath(folder,"datasetA.safetensors"),"SATA") = 0 Then
		Print "ERRO SATA"
	EndIf

	WriteASCII(stream,"DONE")

	CloseStream(stream)

	Print ""
	Print "=========================================="
	Print "DATASET V12 TERMINADO"
	Print "=========================================="

	Print filename

End Function


' ============================================================
' MAIN
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DATASET CODEBOOK ENCODER V12"
	Print "FM 2026"
	Print "=========================================="

	Print ""

	Print "VERSION = " + HEADER_VERSION

	Print "BLOCK = 8x8"

	Print "Y CODEBOOK = " + CODEBOOKSIZEY

	Print "U CODEBOOK = " + CODEBOOKSIZEC

	Print "V CODEBOOK = " + CODEBOOKSIZEC

	Print "A CODEBOOK = " + CODEBOOKSIZEA

	Print ""

	Print "TRAIN MAX IMAGES = " + TRAIN_MAX_IMAGES

	Print "TRAIN MAX BLOCKS = " + TRAIN_MAX_BLOCKS

	Print ""

	Print "YUV /2"

	Print "SEM HAAR"

	Print "SEM ZIGZAG"

	Print "ALPHA RAW LOSSLESS"

	Print ""

	Local folder:String

	folder = Input("Folder das imagens: ")

	If folder = "" Then

		Print "Folder vazio."

		Return

	EndIf

	Local qualityLevel:Int

	qualityLevel = Int(Input("QUALITY 0-100: "))

	If qualityLevel < 0 Then qualityLevel = 0
	If qualityLevel > 100 Then qualityLevel = 100

	' ========================================================
	' TRAINING SAMPLE
	' ========================================================

	Print ""
	Print "=========================================="
	Print "RECOLHER AMOSTRA DE TREINO"
	Print "=========================================="

	Local trainFiles:String[]

	trainFiles = CollectTrainingFiles(folder,TRAIN_MAX_IMAGES)

	If trainFiles = Null Or trainFiles.Length = 0 Then

		Print "ERRO: nao encontrei imagens para treino."

		Return

	EndIf

	Print ""
	Print "Imagens selecionadas para treino = " + trainFiles.Length

	' ========================================================
	' TRAIN Y
	' ========================================================

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	Print ""
	Print "=========================================="
	Print "INICIO TREINO Y"
	Print "=========================================="

	bookY = TrainCodeBook(trainFiles,folder,0,CODEBOOKSIZEY)

	Print ""
	Print "=========================================="
	Print "INICIO TREINO U"
	Print "=========================================="

	bookU = TrainCodeBook(trainFiles,folder,1,CODEBOOKSIZEC)

	Print ""
	Print "=========================================="
	Print "INICIO TREINO V"
	Print "=========================================="

	bookV = TrainCodeBook(trainFiles,folder,2,CODEBOOKSIZEC)

	Print ""
	Print "=========================================="
	Print "INICIO TREINO ALPHA"
	Print "=========================================="

	bookA = TrainCodeBook(trainFiles,folder,3,CODEBOOKSIZEA)

	' ========================================================
	' SAVE EXTERNAL SAFETENSORS
	' ========================================================

	Print ""
	Print "=========================================="
	Print "GRAVAR SAFETENSORS"
	Print "=========================================="

	SaveSafeTensor(bookY,JoinPath(folder,"datasetY.safetensors"),"codebook")

	SaveSafeTensor(bookU,JoinPath(folder,"datasetU.safetensors"),"codebook")

	SaveSafeTensor(bookV,JoinPath(folder,"datasetV.safetensors"),"codebook")

	SaveSafeTensor(bookA,JoinPath(folder,"datasetA.safetensors"),"codebook")

	' ========================================================
	' CREATE DATASET
	' ========================================================

	CreateDataset(folder,bookY,bookU,bookV,bookA,qualityLevel)

	Print ""
	Print "=========================================="
	Print "V12 TERMINADO"
	Print "=========================================="

	Print ""

	Print "dataset.dat"
	Print "datasetY.safetensors"
	Print "datasetU.safetensors"
	Print "datasetV.safetensors"
	Print "datasetA.safetensors"

	Print ""

	Print "Os 4 SafeTensors foram EMBUTIDOS no dataset.dat."

	Print ""

	Print "ALPHA:"
	Print "  RAW"
	Print "  8 BIT"
	Print "  LOSSLESS"
	Print "  64 BYTES/BLOCO"

	Print ""

	Print "BLOCO = 144 BYTES"

	Print ""

	Print "ESC para sair."

End Function


' ============================================================
' RUN
' ============================================================

Main()

Repeat

	Delay(20)

Until KeyHit(KEY_ESCAPE)

EndGraphics