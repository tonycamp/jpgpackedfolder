SuperStrict

Import BRL.StandardIO
Import BRL.Pixmap
Import BRL.PNGLoader
Import BRL.Random


' ============================================================
' DATASET DECODER V11
'
' COMPATIVEL COM:
'
'   DATASET CODEBOOK ENCODER V11
'
' FORMATO:
'
'   DSET
'   VERSION
'   BLOCKSIZE
'   BLOCK_DATA_BYTES
'   CODEBOOK Y
'   CODEBOOK U
'   CODEBOOK V
'   CODEBOOK A
'   QUALITY
'   IMAGE COUNT
'
'   IMAGE HEADERS
'
'   IMAGE BLOCKS
'
'   SAFE
'
'       SATY
'       <size>
'       <datasetY.safetensors>
'
'       SATU
'       <size>
'       <datasetU.safetensors>
'
'       SATV
'       <size>
'       <datasetV.safetensors>
'
'       SATA
'       <size>
'       <datasetA.safetensors>
'
'   DONE
'
'
' BLOCO:
'
'   codeY   = U16
'   codeU   = U16
'   codeV   = U16
'   codeA   = U16
'
'   Y       = 64 bytes
'   U       = 4 bytes
'   V       = 4 bytes
'   A       = 64 bytes RAW
'
'   TOTAL   = 144 bytes
'
' ============================================================


Const BLOCKSIZE:Int = 8
Const BLOCKPIXELS:Int = 64
Const BLOCK_DATA_BYTES:Int = 144

Const HEADER_VERSION:Int = 11


' ============================================================
' IMAGE INFO
' ============================================================

Type TImageInfo

	Field name:String
	Field relativePath:String

	Field width:Int
	Field height:Int

	Field blocks:Int
	Field blocksX:Int
	Field blocksY:Int

End Type


' ============================================================
' CODEBOOK
' ============================================================

Type TCodeBook

	Field size:Int
	Field data:Byte[]

End Type


' ============================================================
' CLAMP
' ============================================================

Function ClampByte:Int(value:Int)

	If value < 0 Then Return 0
	If value > 255 Then Return 255

	Return value

End Function


' ============================================================
' JOIN PATH
' ============================================================

Function JoinPath:String(folder:String,name:String)

	If folder.EndsWith("/") Then
		Return folder + name
	EndIf

	If folder.EndsWith("\") Then
		Return folder + name
	EndIf

	Return folder + "/" + name

End Function


' ============================================================
' NORMALIZE PATH
' ============================================================

Function NormalizeRelativePath:String(path:String)

	Local result:String

	result = path.Replace("\","/")

	While result.StartsWith("./")
		result = result[2..]
	Wend

	Return result

End Function


' ============================================================
' FILE NAME
' ============================================================

Function GetFileNameFromPath:String(path:String)

	Local p:String

	p = NormalizeRelativePath(path)

	Local slash:Int

	slash = p.FindLast("/")

	If slash >= 0 Then
		Return p[slash + 1..]
	EndIf

	Return p

End Function


' ============================================================
' DIRECTORY FROM RELATIVE PATH
' ============================================================

Function GetDirectoryFromPath:String(path:String)

	Local p:String

	p = NormalizeRelativePath(path)

	Local slash:Int

	slash = p.FindLast("/")

	If slash >= 0 Then
		Return p[..slash]
	EndIf

	Return ""

End Function


' ============================================================
' READ U8
' ============================================================

Function ReadU8:Int(stream:TStream)

	Return ReadByte(stream) & $FF

End Function


' ============================================================
' READ U16 LE
' ============================================================

Function ReadU16LE:Int(stream:TStream)

	Local b0:Int
	Local b1:Int

	b0 = ReadU8(stream)
	b1 = ReadU8(stream)

	Return b0 | (b1 Shl 8)

End Function


' ============================================================
' READ U32 LE
' ============================================================

Function ReadU32LE:Int(stream:TStream)

	Local b0:Int
	Local b1:Int
	Local b2:Int
	Local b3:Int

	b0 = ReadU8(stream)
	b1 = ReadU8(stream)
	b2 = ReadU8(stream)
	b3 = ReadU8(stream)

	Return b0 | (b1 Shl 8) | (b2 Shl 16) | (b3 Shl 24)

End Function


' ============================================================
' READ U64 LE
'
' Para tamanhos de ficheiro normais, convertemos para Long.
' ============================================================

Function ReadU64LE:Long(stream:TStream)

	Local value:Long

	value = 0

	For Local i:Int = 0 Until 8

		Local b:Int

		b = ReadU8(stream)

		value = value | (Long(b) Shl (i * 8))

	Next

	Return value

End Function


' ============================================================
' READ ASCII
' ============================================================

Function ReadASCII:String(stream:TStream,count:Int)

	If count <= 0 Then Return ""

	Local result:String

	result = ""

	For Local i:Int = 0 Until count

		Local c:Int

		c = ReadU8(stream)

		result :+ Chr(c)

	Next

	Return result

End Function


' ============================================================
' READ STRING U32
' ============================================================

Function ReadStringU32:String(stream:TStream)

	Local length:Int

	length = ReadU32LE(stream)

	If length < 0 Or length > 10485760 Then

		Print "ERRO: comprimento de string invalido: " + length

		Return ""

	EndIf

	Return ReadASCII(stream,length)

End Function


' ============================================================
' RGB FROM YUV
' ============================================================

Function YUVToR:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)
	vv = Float(v - 128)

	Return ClampByte(Int(yy + 1.596 * vv))

End Function


Function YUVToG:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float
	Local vv:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)
	vv = Float(v - 128)

	Return ClampByte(Int(yy - 0.392 * uu - 0.813 * vv))

End Function


Function YUVToB:Int(y:Int,u:Int,v:Int)

	Local yy:Float
	Local uu:Float

	yy = 1.164 * Float(y - 16)

	uu = Float(u - 128)

	Return ClampByte(Int(yy + 2.017 * uu))

End Function


' ============================================================
' READ IMAGE HEADER
' ============================================================

Function ReadImageHeader:TImageInfo(stream:TStream)

	Local info:TImageInfo

	info = New TImageInfo

	info.relativePath = NormalizeRelativePath(ReadStringU32(stream))

	info.name = GetFileNameFromPath(info.relativePath)

	info.width = ReadU32LE(stream)
	info.height = ReadU32LE(stream)

	info.blocksX = ReadU32LE(stream)
	info.blocksY = ReadU32LE(stream)

	info.blocks = ReadU32LE(stream)

	Return info

End Function


' ============================================================
' CREATE CODEBOOK
' ============================================================

Function CreateCodeBook:TCodeBook(size:Int)

	Local book:TCodeBook

	book = New TCodeBook

	book.size = size
	book.data = New Byte[size * BLOCKPIXELS]

	Return book

End Function


' ============================================================
' READ SAFETENSOR
'
' O encoder grava:
'
'   U64 headerLength
'   JSON header
'   raw U8 data
'
' O tamanho esperado do payload e:
'
'   codebookSize * 64
'
' ============================================================

Function ReadSafeTensorFromDataset:TCodeBook(stream:TStream,expectedSize:Int)

	Print "  A ler SafeTensor..."

	Local headerLength:Long

	headerLength = ReadU64LE(stream)

	If headerLength <= 0 Or headerLength > 1048576 Then

		Print "  ERRO: header SafeTensor invalido: " + headerLength

		Return Null

	EndIf

	Local header:String

	header = ReadASCII(stream,Int(headerLength))

	Print "  Header SafeTensor = " + headerLength + " bytes"

	Print "  JSON = " + header

	Local expectedBytes:Long

	expectedBytes = Long(expectedSize) * Long(BLOCKPIXELS)

	Print "  Payload esperado = " + expectedBytes + " bytes"

	Local book:TCodeBook

	book = CreateCodeBook(expectedSize)

	For Local i:Int = 0 Until book.data.Length

		book.data[i] = Byte(ReadU8(stream))

	Next

	Print "  Payload lido = " + book.data.Length + " bytes"

	Return book

End Function


' ============================================================
' READ EMBEDDED SAFETENSOR
'
' Estrutura:
'
'   TAG 4 bytes
'   U64 file size
'   file bytes
'
' ============================================================

Function ReadEmbeddedSafeTensor:TCodeBook(stream:TStream,expectedTag:String,expectedSize:Int)

	Local tag:String

	tag = ReadASCII(stream,4)

	Print ""
	Print "Embedded tag = " + tag

	If tag <> expectedTag Then

		Print "ERRO: esperado " + expectedTag + " mas encontrei " + tag

		Return Null

	EndIf

	Local FileSize:Long

	FileSize = ReadU64LE(stream)

	Print "Embedded size = " + FileSize

	If FileSize < 8 Then

		Print "ERRO: tamanho SafeTensor invalido."

		Return Null

	EndIf

	Local book:TCodeBook

	book = ReadSafeTensorFromDataset(stream,expectedSize)

	If book = Null Then Return Null

	Return book

End Function


' ============================================================
' CREATE OUTPUT DIRECTORY
' ============================================================

Function EnsureDirectory(path:String)

	If path = "" Then Return

	If FileType(path) = FILETYPE_DIR Then Return

	CreateDir(path,True)

End Function


' ============================================================
' CREATE OUTPUT PATH
' ============================================================

Function MakeOutputPath:String(outputFolder:String,relativePath:String)

	Local clean:String

	clean = NormalizeRelativePath(relativePath)

	Local directory:String

	directory = GetDirectoryFromPath(clean)

	If directory <> "" Then

		EnsureDirectory(JoinPath(outputFolder,directory))

	EndIf

	Return JoinPath(outputFolder,clean)

End Function


' ============================================================
' DECODE ONE IMAGE
' ============================================================

Function DecodeImage:TPixmap(stream:TStream,info:TImageInfo,bookY:TCodeBook,bookU:TCodeBook,bookV:TCodeBook,bookA:TCodeBook,qualityLevel:Int)

	Print ""
	Print "=========================================="
	Print "DECODIFICAR: " + info.relativePath
	Print "=========================================="

	Print "Size    = " + info.width + " x " + info.height
	Print "BlocksX = " + info.blocksX
	Print "BlocksY = " + info.blocksY
	Print "Blocks  = " + info.blocks
	Print "Quality = " + qualityLevel

	Local output:TPixmap

	output = CreatePixmap(info.width,info.height,PF_RGBA8888)

	If output = Null Then

		Print "ERRO: nao consegui criar pixmap."

		Return Null

	EndIf


	' ========================================================
	' MESMA QUANTIZACAO DO ENCODER
	' ========================================================

	Local quantY:Int
	Local quantC:Int

	quantY = 64 - (qualityLevel * 63 / 100)
	quantC = 96 - (qualityLevel * 95 / 100)

	If quantY < 1 Then quantY = 1
	If quantC < 1 Then quantC = 1

	Print "Quant Y = " + quantY
	Print "Quant C = " + quantC


	' ========================================================
	' BUFFERS
	' ========================================================

	Local residualY:Int[]
	Local residualU:Int[]
	Local residualV:Int[]
	Local alpha:Int[]

	residualY = New Int[64]
	residualU = New Int[4]
	residualV = New Int[4]
	alpha = New Int[64]


	' ========================================================
	' BLOCKS
	' ========================================================

	For Local by:Int = 0 Until info.blocksY

		For Local bx:Int = 0 Until info.blocksX

			' =================================================
			' READ CODE IDS
			' =================================================

			Local codeY:Int
			Local codeU:Int
			Local codeV:Int
			Local codeA:Int

			codeY = ReadU16LE(stream)
			codeU = ReadU16LE(stream)
			codeV = ReadU16LE(stream)
			codeA = ReadU16LE(stream)

			If codeY < 0 Or codeY >= bookY.size Then

				Print "ERRO codeY = " + codeY

				Return Null

			EndIf

			If codeU < 0 Or codeU >= bookU.size Then

				Print "ERRO codeU = " + codeU

				Return Null

			EndIf

			If codeV < 0 Or codeV >= bookV.size Then

				Print "ERRO codeV = " + codeV

				Return Null

			EndIf

			If codeA < 0 Or codeA >= bookA.size Then

				Print "ERRO codeA = " + codeA

				Return Null

			EndIf


			' =================================================
			' READ Y
			'
			' encoder:
			'
			' residual + 128
			'
			' decoder:
			'
			' byte - 128
			' =================================================

			For Local i:Int = 0 Until 64

				residualY[i] = ReadU8(stream) - 128

			Next


			' =================================================
			' READ U
			' =================================================

			For Local i:Int = 0 Until 4

				residualU[i] = ReadU8(stream) - 128

			Next


			' =================================================
			' READ V
			' =================================================

			For Local i:Int = 0 Until 4

				residualV[i] = ReadU8(stream) - 128

			Next


			' =================================================
			' READ ALPHA
			'
			' V11:
			'
			' RAW
			'
			' sem -128
			' sem residual
			' sem quantizacao
			' =================================================

			For Local i:Int = 0 Until 64

				alpha[i] = ReadU8(stream)

			Next


			' =================================================
			' CODEBOOK BASE
			' =================================================

			Local baseY:Int
			Local baseU:Int
			Local baseV:Int
			Local baseA:Int

			baseY = codeY * 64
			baseU = codeU * 64
			baseV = codeV * 64
			baseA = codeA * 64


			' =================================================
			' RECONSTRUCTION
			' =================================================

			For Local yy:Int = 0 Until 8

				For Local xx:Int = 0 Until 8

					Local p:Int

					p = yy * 8 + xx


					' =============================================
					' Y
					' =============================================

					Local ry:Int

					ry = residualY[p] * quantY

					Local yHalf:Int

					yHalf = Int(bookY.data[baseY + p] & $FF) + ry


					' =============================================
					' U / V
					'
					' encoder usa:
					'
					' ci = (yy / 4) * 2 + (xx / 4)
					' =============================================

					Local ci:Int

					ci = (yy / 4) * 2 + (xx / 4)

					Local ru:Int
					Local rv:Int

					ru = residualU[ci] * quantC
					rv = residualV[ci] * quantC

					Local uHalf:Int
					Local vHalf:Int

					uHalf = Int(bookU.data[baseU + p] & $FF) + ru
					vHalf = Int(bookV.data[baseV + p] & $FF) + rv


					' =============================================
					' V11 YUV /2
					'
					' encoder:
					'
					'   YUV -> /2
					'
					' decoder:
					'
					'   /2 -> *2
					' =============================================

					Local yv:Int
					Local uv:Int
					Local vv:Int

					yv = ClampByte(yHalf * 2)
					uv = ClampByte(uHalf * 2)
					vv = ClampByte(vHalf * 2)


					' =============================================
					' YUV -> RGB
					' =============================================

					Local r:Int
					Local g:Int
					Local b:Int

					r = YUVToR(yv,uv,vv)
					g = YUVToG(yv,uv,vv)
					b = YUVToB(yv,uv,vv)


					' =============================================
					' ALPHA
					'
					' IMPORTANTE:
					'
					' V11 nao usa codeA para reconstruir alpha.
					'
					' O alpha original esta em alpha[p].
					' =============================================

					Local a:Int

					a = alpha[p]

					If a < 0 Then a = 0
					If a > 255 Then a = 255


					' =============================================
					' REAL IMAGE COORDINATE
					'
					' Padding nunca e escrito.
					' =============================================

					Local outX:Int
					Local outY:Int

					outX = bx * BLOCKSIZE + xx
					outY = by * BLOCKSIZE + yy

					If outX < info.width And outY < info.height Then

						Local pixel:Int

						pixel = (a Shl 24) | (r Shl 16) | (g Shl 8) | b

						WritePixel(output,outX,outY,pixel)

					EndIf

				Next

			Next

		Next

		If by Mod 16 = 0 Or by = info.blocksY - 1 Then

			Print "  Linha " + by + " / " + info.blocksY

		EndIf

	Next

	Return output

End Function


' ============================================================
' SAVE PNG
' ============================================================

Function SaveDecodedPNG:Int(pix:TPixmap,filename:String)

	If pix = Null Then Return 0

	Print "A gravar: " + filename

	EnsureDirectory(GetDirectoryFromPath(filename))

	' ========================================================
	' BlitzMax PNG loader
	' ========================================================

	Local result:Int

	result = SavePixmapPNG(pix,filename)

	If result = 0 Then

		Print "ERRO ao gravar PNG: " + filename

		Return 0

	EndIf

	Print "OK: " + filename

	Return 1

End Function


' ============================================================
' LOAD FOUR CODEBOOKS FROM EMBEDDED DATA
' ============================================================

Function ReadAllEmbeddedCodeBooks:Int(stream:TStream,bookY:TCodeBook Var,bookU:TCodeBook Var,bookV:TCodeBook Var,bookA:TCodeBook Var)

	Print ""
	Print "=========================================="
	Print "LER SAFETENSORS EMBUTIDOS"
	Print "=========================================="


	' ========================================================
	' SATY
	' ========================================================

	bookY = ReadEmbeddedSafeTensor(stream,"SATY",4096)

	If bookY = Null Then

		Print "ERRO ao ler datasetY.safetensors"

		Return 0

	EndIf


	' ========================================================
	' SATU
	' ========================================================

	bookU = ReadEmbeddedSafeTensor(stream,"SATU",1024)

	If bookU = Null Then

		Print "ERRO ao ler datasetU.safetensors"

		Return 0

	EndIf


	' ========================================================
	' SATV
	' ========================================================

	bookV = ReadEmbeddedSafeTensor(stream,"SATV",1024)

	If bookV = Null Then

		Print "ERRO ao ler datasetV.safetensors"

		Return 0

	EndIf


	' ========================================================
	' SATA
	' ========================================================

	bookA = ReadEmbeddedSafeTensor(stream,"SATA",256)

	If bookA = Null Then

		Print "ERRO ao ler datasetA.safetensors"

		Return 0

	EndIf


	Print ""
	Print "Todos os SafeTensors foram lidos."

	Return 1

End Function


' ============================================================
' MAIN DECODER
' ============================================================

Function Main()

	Print ""
	Print "=========================================="
	Print "DATASET CODEBOOK DECODER V11"
	Print "BLITZMAX NG"
	Print "=========================================="
	Print ""

	Local filename:String

	filename = Input("dataset.dat: ")

	If filename = "" Then

		Print "Nome vazio."

		Return

	EndIf

	If Not FileExists(filename) Then

		Print "ERRO: ficheiro nao existe."

		Return

	EndIf


	' ========================================================
	' OUTPUT
	' ========================================================

	Local outputFolder:String

	outputFolder = Input("Pasta de saida: ")

	If outputFolder = "" Then

		outputFolder = "decoded"

	EndIf

	EnsureDirectory(outputFolder)


	' ========================================================
	' OPEN DATASET
	' ========================================================

	Local stream:TStream

	stream = ReadStream(filename)

	If stream = Null Then

		Print "ERRO: nao consegui abrir dataset."

		Return

	EndIf


	' ========================================================
	' MAGIC
	' ========================================================

	Local magic:String

	magic = ReadASCII(stream,4)

	If magic <> "DSET" Then

		Print "ERRO: nao e um dataset DSET."

		CloseStream(stream)

		Return

	EndIf

	Print "Magic = " + magic


	' ========================================================
	' HEADER
	' ========================================================

	Local version:Int

	version = ReadU32LE(stream)

	Print "Version = " + version

	If version <> HEADER_VERSION Then

		Print "ERRO: este decoder espera V11."

		CloseStream(stream)

		Return

	EndIf


	Local blockSize:Int
	Local blockDataBytes:Int

	blockSize = ReadU32LE(stream)
	blockDataBytes = ReadU32LE(stream)

	Print "BlockSize = " + blockSize
	Print "BlockData = " + blockDataBytes

	If blockSize <> 8 Then

		Print "ERRO: BLOCKSIZE diferente de 8."

		CloseStream(stream)

		Return

	EndIf

	If blockDataBytes <> 144 Then

		Print "ERRO: tamanho de bloco diferente de 144."

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' CODEBOOK SIZES
	' ========================================================

	Local codebookYSize:Int
	Local codebookUSize:Int
	Local codebookVSize:Int
	Local codebookASize:Int

	codebookYSize = ReadU32LE(stream)
	codebookUSize = ReadU32LE(stream)
	codebookVSize = ReadU32LE(stream)
	codebookASize = ReadU32LE(stream)

	Print "Codebook Y = " + codebookYSize
	Print "Codebook U = " + codebookUSize
	Print "Codebook V = " + codebookVSize
	Print "Codebook A = " + codebookASize


	' ========================================================
	' QUALITY
	' ========================================================

	Local qualityLevel:Int

	qualityLevel = ReadU32LE(stream)

	Print "Quality = " + qualityLevel


	' ========================================================
	' IMAGE COUNT
	' ========================================================

	Local imageCount:Int

	imageCount = ReadU32LE(stream)

	Print "Images = " + imageCount

	If imageCount <= 0 Then

		Print "ERRO: dataset sem imagens."

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' READ IMAGE HEADERS
	' ========================================================

	Local images:TImageInfo[]

	images = New TImageInfo[imageCount]

	Print ""
	Print "=========================================="
	Print "IMAGE HEADERS"
	Print "=========================================="


	For Local i:Int = 0 Until imageCount

		Local info:TImageInfo

		info = ReadImageHeader(stream)

		If info.width <= 0 Or info.height <= 0 Then

			Print "ERRO: dimensao invalida na imagem " + i

			CloseStream(stream)

			Return

		EndIf

		If info.blocksX <= 0 Or info.blocksY <= 0 Then

			Print "ERRO: blocos invalidos na imagem " + i

			CloseStream(stream)

			Return

		EndIf

		If info.blocks <> info.blocksX * info.blocksY Then

			Print "ERRO: contagem de blocos inconsistente."

			CloseStream(stream)

			Return

		EndIf

		images[i] = info

		Print ""
		Print "[" + i + "] " + info.relativePath
		Print "  Size   = " + info.width + " x " + info.height
		Print "  Blocks = " + info.blocks
		Print "  X      = " + info.blocksX
		Print "  Y      = " + info.blocksY

	Next


	' ========================================================
	' IMPORTANTE
	'
	' Os SafeTensors estao DEPOIS dos blocos.
	'
	' Portanto primeiro precisamos ler todos os blocos.
	'
	' Como a imagem e reconstruida imediatamente, os codebooks
	' ainda nao estao disponiveis.
	'
	' Assim fazemos uma segunda passagem no ficheiro:
	'
	' 1. guardamos a posicao onde começam os blocos
	' 2. saltamos todos os blocos
	' 3. lemos SafeTensors
	' 4. voltamos a posicao dos blocos
	' 5. decodificamos.
	'
	' ========================================================

	Local blocksStart:Long

	blocksStart = StreamPos(stream)

	Print ""
	Print "BlocksStart = " + blocksStart


	' ========================================================
	' CALCULATE TOTAL BLOCK BYTES
	' ========================================================

	Local totalBlockCount:Long

	totalBlockCount = 0

	For Local i:Int = 0 Until imageCount

		totalBlockCount :+ Long(images[i].blocks)

	Next

	Local totalBlockBytes:Long

	totalBlockBytes = totalBlockCount * Long(BLOCK_DATA_BYTES)

	Print "Total blocks = " + totalBlockCount
	Print "Total block bytes = " + totalBlockBytes


	' ========================================================
	' SKIP BLOCK DATA
	' ========================================================

	Local safePosition:Long

	safePosition = blocksStart + totalBlockBytes

	Print "SAFE position = " + safePosition

	SeekStream(stream,safePosition)


	' ========================================================
	' SAFE MARKER
	' ========================================================

	Local safeMagic:String

	safeMagic = ReadASCII(stream,4)

	If safeMagic <> "SAFE" Then

		Print "ERRO: marcador SAFE nao encontrado."

		Print "Encontrado = [" + safeMagic + "]"

		CloseStream(stream)

		Return

	EndIf

	Print "SAFE = OK"


	' ========================================================
	' READ EMBEDDED CODEBOOKS
	' ========================================================

	Local bookY:TCodeBook
	Local bookU:TCodeBook
	Local bookV:TCodeBook
	Local bookA:TCodeBook

	If ReadAllEmbeddedCodeBooks(stream,bookY,bookU,bookV,bookA) = 0 Then

		CloseStream(stream)

		Return

	EndIf


	' ========================================================
	' DONE MARKER
	'
	' Depois dos 4 SafeTensors deve existir:
	'
	' DONE
	'
	' ========================================================

	Local doneMagic:String

	doneMagic = ReadASCII(stream,4)

	Print ""
	Print "DONE = [" + doneMagic + "]"

	If doneMagic <> "DONE" Then

		Print "AVISO: marcador DONE nao encontrado."

	EndIf


	' ========================================================
	' VOLTAR PARA OS BLOCOS
	' ========================================================

	Print ""
	Print "=========================================="
	Print "INICIO DECODIFICACAO"
	Print "=========================================="

	SeekStream(stream,blocksStart)


	' ========================================================
	' DECODE IMAGES
	' ========================================================

	For Local i:Int = 0 Until imageCount

		Local info:TImageInfo

		info = images[i]

		Local reconstructed:TPixmap

		reconstructed = DecodeImage(stream,info,bookY,bookU,bookV,bookA,qualityLevel)

		If reconstructed = Null Then

			Print "ERRO ao reconstruir " + info.relativePath

			CloseStream(stream)

			Return

		EndIf

		Local outputPath:String

		outputPath = MakeOutputPath(outputFolder,info.relativePath)

		' =====================================================
		' Garantir PNG.
		'
		' Se o nome original nao for .png, acrescentamos
		' "_decoded.png" para nao alterar o original.
		' =====================================================

		Local Lower:String

		Lower = info.relativePath.ToLower()

		If Lower.EndsWith(".png") Then

			outputPath = JoinPath(outputFolder,info.relativePath)

		Else

			Local directory:String
			Local name:String

			directory = GetDirectoryFromPath(info.relativePath)
			name = GetFileNameFromPath(info.relativePath)

			Local dot:Int

			dot = name.FindLast(".")

			If dot >= 0 Then
				name = name[..dot]
			EndIf

			name :+ "_decoded.png"

			If directory <> "" Then
				outputPath = JoinPath(outputFolder,JoinPath(directory,name))
			Else
				outputPath = JoinPath(outputFolder,name)
			EndIf

		EndIf


		If SaveDecodedPNG(reconstructed,outputPath) = 0 Then

			Print "ERRO a gravar imagem."

		EndIf

	Next


	' ========================================================
	' CLOSE
	' ========================================================

	CloseStream(stream)

	Print ""
	Print "=========================================="
	Print "DECODER V11 TERMINADO"
	Print "=========================================="
	Print ""

	Print "Dataset:"
	Print filename

	Print ""

	Print "Saida:"
	Print outputFolder

	Print ""

	Print "Images:"
	Print imageCount

	Print ""

	Print "Codebook Y:"
	Print bookY.size

	Print "Codebook U:"
	Print bookU.size

	Print "Codebook V:"
	Print bookV.size

	Print "Codebook A:"
	Print bookA.size

	Print ""

	Print "ALPHA:"
	Print "RAW 8-BIT"
	Print "LOSSLESS"

	Print ""

	Print "V11 OK."

End Function


' ============================================================
' RUN
' ============================================================

Main()